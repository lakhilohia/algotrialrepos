import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.json());

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// AI Algo Audit Endpoint
app.post('/api/ai/audit-stock', async (req, res) => {
  try {
    const { symbol, currentPrice, change24h, rsi, trend, timeframe, sector } = req.body;

    const prompt = `You are the StrykeX Institutional Algorithmic Engine & Trading Advisor.
Analyze the following stock/asset setup and provide a crystal-clear, foolproof institutional algorithmic trading plan:
Symbol: ${symbol}
Current Price: ₹${currentPrice}
24h Trend: ${trend} (${change24h > 0 ? '+' : ''}${change24h}%)
RSI (14): ${rsi}
Timeframe: ${timeframe || '15-min Intraday'}
Sector: ${sector || 'Equities'}

The user explicitly needs to know:
1. "When to invest in which stock at which time" -> Exact Trigger condition (price zone & time/candle confirmation).
2. "When to exit with booking profit" -> Target 1 (book 50%), Target 2 (book 30%), Target 3/Runner.
3. "Kab stop loss lagana hai" -> Exactly when to place the stop loss (e.g., IMMEDIATELY on entry fill), exact SL price, and the Trailing Stop Loss mechanics (shift SL to break-even after T1).

Provide the output strictly in valid JSON format matching this schema:
{
  "verdict": "STRONG_BUY" | "BUY" | "WAIT_PULLBACK" | "SELL_SHORT" | "NEUTRAL",
  "confidenceScore": number (between 70 and 96),
  "entryTiming": "Exact time/candle trigger (e.g., 'Trigger on 15m candle close above ₹... between 09:30 - 11:30 AM IST')",
  "entryPriceZone": "₹... - ₹...",
  "target1": {
    "price": number,
    "percentGain": number,
    "action": "Book 50% profit and trail Stop Loss immediately to entry cost"
  },
  "target2": {
    "price": number,
    "percentGain": number,
    "action": "Book 30% profit and trail SL to Target 1 price"
  },
  "target3Runner": {
    "price": number,
    "percentGain": number,
    "action": "Ride runner 20% quantity with Supertrend trailing stop"
  },
  "stopLoss": {
    "price": number,
    "percentRisk": number,
    "kabLaganaHai": "Kab lagana hai: Order fill hote hi immediately system me hard stop-loss trigger place karo. Do not wait for mental SL!",
    "invalidationRule": "If 15m candle closes below ₹... or VWAP breaks downward"
  },
  "riskRewardRatio": "1 : ...",
  "institutionalReasoning": "Concise 2-sentence breakdown of Smart Money / Order Block / Liquidity sweep reason.",
  "hinglishSummary": "2-3 crisp lines in Hindi/Hinglish directly guiding: kab kharidna hai, kab profit book karna hai, aur stop loss kab aur kaise lagana hai."
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Gemini Stock Audit error:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to generate algorithmic trade audit',
    });
  }
});

// AI Chat Advisor Endpoint
app.post('/api/ai/chat-advisor', async (req, res) => {
  try {
    const { message, activeStock } = req.body;

    const systemPrompt = `You are StrykeX Institutional Trading Copilot. You speak professional, punchy, crisp English with clear Hinglish guidance when discussing rules like Stop-Loss and Profit Booking.
Golden Rules you teach:
- Rule 1: "Never enter a trade without a predefined Stop Loss. Stop loss entry lete hi system me order laga do."
- Rule 2: "Target 1 hit hote hi 50% profit book karo aur Stop Loss ko Cost (Entry Price) par le aao (Free Trade rule)."
- Rule 3: "Never risk more than 1-2% of total capital per trade."
Stock Context: ${activeStock ? JSON.stringify(activeStock) : 'General Market & Algo Strategy'}.
Answer the trader's query with actionable numerical guidance, precise timing, entry rules, and exit/SL strategy.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: message,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    return res.json({ success: true, answer: response.text });
  } catch (error: any) {
    console.error('Gemini Chat Advisor error:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to chat with AI Advisor',
    });
  }
});

// AI Strategy Backtest Generator
app.post('/api/ai/backtest-strategy', async (req, res) => {
  try {
    const { strategyName, indicators, riskPerTrade, timeframe } = req.body;

    const prompt = `Analyze and evaluate the algorithmic backtest for strategy: "${strategyName}"
Indicators used: ${indicators.join(', ')}
Risk Per Trade: ${riskPerTrade}%
Timeframe: ${timeframe}

Return strict JSON:
{
  "winRate": number (e.g. 76.8),
  "profitFactor": number (e.g. 2.34),
  "totalTrades": number (e.g. 412),
  "maxDrawdown": number (e.g. 6.4),
  "netRoi12Month": number (e.g. 164.2),
  "niftyBenchmarkRoi": 14.5,
  "optimalExitRule": "string explaining target exit",
  "stopLossExecutionRule": "string explaining exact stop loss placement",
  "institutionalRating": "A+" | "A" | "B+" | "B"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Gemini Backtest error:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to backtest strategy',
    });
  }
});

// Vite Middleware for Full-stack Dev
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`StrykeX Algo Engine running on http://0.0.0.0:${port}`);
  });
}

startServer();
