import { StockItem, Candle } from '../types/trading';

// Helper to calculate EMA
function calculateEMA(prices: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const emaArray: number[] = [];
  let ema = prices[0];
  for (let i = 0; i < prices.length; i++) {
    if (i === 0) {
      ema = prices[i];
    } else {
      ema = prices[i] * k + ema * (1 - k);
    }
    emaArray.push(Number(ema.toFixed(2)));
  }
  return emaArray;
}

// Generate realistic candle series
function generateCandles(basePrice: number, volatility: number, trendBias: number = 0.001): Candle[] {
  const candles: Candle[] = [];
  let currentPrice = basePrice * 0.94;
  const now = Date.now();
  const rawCloses: number[] = [];

  for (let i = 60; i >= 0; i--) {
    const timestamp = now - i * 15 * 60 * 1000;
    const date = new Date(timestamp);
    const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const change = (Math.random() - 0.47 + trendBias) * volatility * currentPrice;
    const open = currentPrice;
    const close = Math.max(open * 0.8, open + change);
    const high = Math.max(open, close) + Math.random() * volatility * currentPrice * 0.6;
    const low = Math.min(open, close) - Math.random() * volatility * currentPrice * 0.6;
    const volume = Math.floor(25000 + Math.random() * 85000 + (Math.abs(change) / currentPrice) * 120000);

    currentPrice = close;
    rawCloses.push(close);

    candles.push({
      time: timeStr,
      timestamp,
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume,
    });
  }

  const ema20 = calculateEMA(rawCloses, 20);
  const ema50 = calculateEMA(rawCloses, 50);

  return candles.map((c, idx) => ({
    ...c,
    ema20: ema20[idx],
    ema50: ema50[idx],
  }));
}

export const initialStocks: StockItem[] = [
  {
    symbol: 'RELIANCE',
    name: 'Reliance Industries Ltd.',
    exchange: 'NSE',
    price: 2942.50,
    prevClose: 2898.10,
    change: 44.40,
    changePercent: 1.53,
    dayHigh: 2955.00,
    dayLow: 2895.00,
    volume: 6420500,
    avgVolume: 4120000,
    rsi: 64.8,
    trend: 'STRONGLY_BULLISH',
    signal: 'STRONG_BUY',
    algoSetup: {
      name: 'Smart Money Liquidity Sweep & 15m ORB Breakout',
      description: 'Institutional buying volume confirmed on 20 EMA pullback with high delivery percentage.',
      triggerCondition: 'Breakout above Day High (₹2,945) on 15-minute candle with Volume > 1.8x Average.',
      triggerTime: 'Execute between 09:45 AM - 11:15 AM IST (Peak institutional liquidity window)',
      entryZone: {
        min: 2938.00,
        max: 2945.00,
        ideal: 2942.50,
      },
      target1: {
        price: 2995.00,
        gainPercent: 1.78,
        sharesToExitPercent: 50,
        instruction: 'Book 50% profit. Shift Stop Loss immediately to Cost (₹2,942.50) to make trade risk-free!',
      },
      target2: {
        price: 3045.00,
        gainPercent: 3.48,
        sharesToExitPercent: 30,
        instruction: 'Book 30% profit. Trail Stop Loss to Target 1 level (₹2,995.00).',
      },
      target3Runner: {
        price: 3110.00,
        gainPercent: 5.69,
        sharesToExitPercent: 20,
        instruction: 'Hold remaining 20% quantity until 15m Supertrend turns Red or closes below 20 EMA.',
      },
      stopLoss: {
        price: 2912.00,
        riskPercent: 1.04,
        timingRule: 'KAB LAGANA HAI: Buy order fill hote hi 5 SECONDS ke andar terminal me Hard Stop Loss (₹2,912) place karo. No mental stop loss!',
        trailingRule: 'Jab Target 1 (₹2,995) hit ho, Stop Loss ko ₹2,943 pe shift kar do. Capital 100% safe ho jayega.',
        invalidation: 'Any 15m candle close below ₹2,912 invalidates the institutional order block.',
      },
      riskRewardRatio: '1 : 2.85',
      winProbability: 84.2,
      sector: 'Energy & Retail',
    },
    candles: generateCandles(2942.50, 0.0035, 0.0018),
  },
  {
    symbol: 'HDFCBANK',
    name: 'HDFC Bank Limited',
    exchange: 'NSE',
    price: 1748.20,
    prevClose: 1730.00,
    change: 18.20,
    changePercent: 1.05,
    dayHigh: 1754.00,
    dayLow: 1728.50,
    volume: 9140200,
    avgVolume: 7200000,
    rsi: 58.4,
    trend: 'BULLISH',
    signal: 'BUY',
    algoSetup: {
      name: 'VWAP Institutional Pullback & Absorption',
      description: 'Price tested VWAP line and printed a strong bullish hammer candle with institutional volume.',
      triggerCondition: 'Enter when price breaks above ₹1,749 with RSI > 55.',
      triggerTime: 'Optimal entry: 10:30 AM or 01:15 PM IST (After European market opening cues)',
      entryZone: {
        min: 1744.00,
        max: 1749.00,
        ideal: 1748.00,
      },
      target1: {
        price: 1778.00,
        gainPercent: 1.71,
        sharesToExitPercent: 50,
        instruction: 'Book 50% profit. Shift Stop Loss to Entry ₹1,748 (Zero Risk).',
      },
      target2: {
        price: 1805.00,
        gainPercent: 3.26,
        sharesToExitPercent: 30,
        instruction: 'Book 30% profit. Trail Stop Loss to ₹1,778.',
      },
      target3Runner: {
        price: 1840.00,
        gainPercent: 5.26,
        sharesToExitPercent: 20,
        instruction: 'Let runner 20% ride for weekly swing targets.',
      },
      stopLoss: {
        price: 1731.00,
        riskPercent: 0.97,
        timingRule: 'KAB LAGANA HAI: Entry lete hi turant SL ₹1,731.00 laga do. Intraday low ke 1 point niche.',
        trailingRule: 'T1 hit hone par SL = ₹1,749 (Entry Cost + Brokerage safe).',
        invalidation: 'Break below ₹1,730 support invalidates the banking momentum setup.',
      },
      riskRewardRatio: '1 : 2.90',
      winProbability: 79.5,
      sector: 'Banking & Financials',
    },
    candles: generateCandles(1748.20, 0.003, 0.0014),
  },
  {
    symbol: 'TATASTEEL',
    name: 'Tata Steel Limited',
    exchange: 'NSE',
    price: 156.40,
    prevClose: 152.80,
    change: 3.60,
    changePercent: 2.36,
    dayHigh: 157.20,
    dayLow: 152.10,
    volume: 24500000,
    avgVolume: 14800000,
    rsi: 71.2,
    trend: 'STRONGLY_BULLISH',
    signal: 'STRONG_BUY',
    algoSetup: {
      name: 'High-Volume Metals Momentum Breakout',
      description: 'Massive surge in open interest and volume breakout across base metals index.',
      triggerCondition: 'Immediate market buy or limit order in ₹155.80 - ₹156.50 zone.',
      triggerTime: 'Now active (Triggered at 10:15 AM IST breakout)',
      entryZone: {
        min: 155.50,
        max: 156.60,
        ideal: 156.20,
      },
      target1: {
        price: 160.50,
        gainPercent: 2.75,
        sharesToExitPercent: 50,
        instruction: 'Book 50% profit. Trail Stop Loss immediately to ₹156.40.',
      },
      target2: {
        price: 164.80,
        gainPercent: 5.51,
        sharesToExitPercent: 30,
        instruction: 'Book 30% profit. Trail SL to ₹160.50.',
      },
      target3Runner: {
        price: 170.00,
        gainPercent: 8.84,
        sharesToExitPercent: 20,
        instruction: 'Swing runner for target ₹170.',
      },
      stopLoss: {
        price: 153.90,
        riskPercent: 1.47,
        timingRule: 'KAB LAGANA HAI: Buy karte hi order window me SL Trigger: ₹153.90 daalein. Stop-Loss lagana mandatory hai.',
        trailingRule: 'Target 1 par 50% profit lock karke SL cost par trail karein.',
        invalidation: 'Drop below ₹153.80 invalidates momentum.',
      },
      riskRewardRatio: '1 : 3.10',
      winProbability: 86.4,
      sector: 'Metals & Mining',
    },
    candles: generateCandles(156.40, 0.0045, 0.0022),
  },
  {
    symbol: 'INFY',
    name: 'Infosys Limited',
    exchange: 'NSE',
    price: 1892.00,
    prevClose: 1910.50,
    change: -18.50,
    changePercent: -0.97,
    dayHigh: 1915.00,
    dayLow: 1886.00,
    volume: 3820000,
    avgVolume: 3500000,
    rsi: 42.1,
    trend: 'SIDEWAYS',
    signal: 'WAIT_PULLBACK',
    algoSetup: {
      name: 'Mean Reversion Oversold Bounce Setup',
      description: 'Stock is testing strong 200 EMA support with bullish divergence on 15m RSI.',
      triggerCondition: 'DO NOT BUY NOW. Wait for price to touch ₹1,880 support and print a green reversal candle.',
      triggerTime: 'Anticipated trigger: 01:45 PM - 02:30 PM IST (Late afternoon recovery)',
      entryZone: {
        min: 1878.00,
        max: 1885.00,
        ideal: 1882.00,
      },
      target1: {
        price: 1915.00,
        gainPercent: 1.75,
        sharesToExitPercent: 60,
        instruction: 'Book 60% profit near 20 EMA resistance.',
      },
      target2: {
        price: 1935.00,
        gainPercent: 2.81,
        sharesToExitPercent: 40,
        instruction: 'Book remaining 40% profit.',
      },
      target3Runner: {
        price: 1955.00,
        gainPercent: 3.88,
        sharesToExitPercent: 0,
        instruction: 'Full exit at Target 2 for mean reversion trades.',
      },
      stopLoss: {
        price: 1868.00,
        riskPercent: 0.74,
        timingRule: 'KAB LAGANA HAI: Jaise hi pullback entry trigger ho, turant ₹1,868 ka SL lagao. Support break par turant exit.',
        trailingRule: 'T1 hit hone ke baad SL = ₹1,882 (Cost).',
        invalidation: 'Close below ₹1,868 on 15m candle.',
      },
      riskRewardRatio: '1 : 2.50',
      winProbability: 72.8,
      sector: 'Information Technology',
    },
    candles: generateCandles(1892.00, 0.0032, -0.0008),
  },
  {
    symbol: 'TATAMOTORS',
    name: 'Tata Motors Passenger Vehicles',
    exchange: 'NSE',
    price: 812.50,
    prevClose: 798.00,
    change: 14.50,
    changePercent: 1.82,
    dayHigh: 816.00,
    dayLow: 795.50,
    volume: 12400000,
    avgVolume: 8900000,
    rsi: 66.7,
    trend: 'STRONGLY_BULLISH',
    signal: 'STRONG_BUY',
    algoSetup: {
      name: 'Golden Cross 20/50 EMA Squeeze Breakout',
      description: 'Consolidation squeeze resolved to the upside with strong auto delivery volumes.',
      triggerCondition: 'Enter on any minor dip towards ₹810 - ₹812.',
      triggerTime: 'Active now (Optimal morning momentum window)',
      entryZone: {
        min: 809.00,
        max: 813.00,
        ideal: 811.50,
      },
      target1: {
        price: 828.00,
        gainPercent: 1.97,
        sharesToExitPercent: 50,
        instruction: 'Book 50% profit. Shift Stop Loss to ₹812.00 (Cost price).',
      },
      target2: {
        price: 845.00,
        gainPercent: 4.06,
        sharesToExitPercent: 30,
        instruction: 'Book 30% profit. Trail Stop Loss to ₹828.',
      },
      target3Runner: {
        price: 865.00,
        gainPercent: 6.52,
        sharesToExitPercent: 20,
        instruction: 'Hold runner with trailing Supertrend.',
      },
      stopLoss: {
        price: 802.00,
        riskPercent: 1.17,
        timingRule: 'KAB LAGANA HAI: Buy click karne ke sath hi ₹802.00 ka SL order daal do. Risk management is non-negotiable.',
        trailingRule: 'T1 aane par cost par SL trail karo.',
        invalidation: 'Any breakdown below 50 EMA (₹802) invalidates setup.',
      },
      riskRewardRatio: '1 : 2.95',
      winProbability: 83.1,
      sector: 'Automobile',
    },
    candles: generateCandles(812.50, 0.0038, 0.002),
  },
  {
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    exchange: 'NASDAQ',
    price: 142.80,
    prevClose: 139.10,
    change: 3.70,
    changePercent: 2.66,
    dayHigh: 143.50,
    dayLow: 139.50,
    volume: 58400000,
    avgVolume: 42000000,
    rsi: 69.4,
    trend: 'STRONGLY_BULLISH',
    signal: 'STRONG_BUY',
    algoSetup: {
      name: 'AI Semiconductor Super-Cycle Breakout',
      description: 'Institutional accumulation flags breaking out of all-time resistance band.',
      triggerCondition: 'Enter at market between $142.00 - $143.00.',
      triggerTime: 'US Market open 09:30 AM - 10:15 AM EST',
      entryZone: {
        min: 141.80,
        max: 143.00,
        ideal: 142.50,
      },
      target1: {
        price: 146.50,
        gainPercent: 2.59,
        sharesToExitPercent: 50,
        instruction: 'Book 50% profit. Shift Stop Loss to Cost ($142.50).',
      },
      target2: {
        price: 151.00,
        gainPercent: 5.74,
        sharesToExitPercent: 30,
        instruction: 'Book 30% profit. Trail SL to $146.50.',
      },
      target3Runner: {
        price: 158.00,
        gainPercent: 10.65,
        sharesToExitPercent: 20,
        instruction: 'Hold remaining 20% for trend continuation.',
      },
      stopLoss: {
        price: 139.80,
        riskPercent: 1.89,
        timingRule: 'KAB LAGANA HAI: Place $139.80 hard stop loss immediately with the buy order in broker.',
        trailingRule: 'Trail SL to entry price once Target 1 is touched.',
        invalidation: 'Break below prior swing low $139.50.',
      },
      riskRewardRatio: '1 : 3.05',
      winProbability: 85.0,
      sector: 'Semiconductors',
    },
    candles: generateCandles(142.80, 0.005, 0.0025),
  },
  {
    symbol: 'ICICIBANK',
    name: 'ICICI Bank Limited',
    exchange: 'NSE',
    price: 1285.60,
    prevClose: 1272.00,
    change: 13.60,
    changePercent: 1.07,
    dayHigh: 1290.00,
    dayLow: 1269.00,
    volume: 8700000,
    avgVolume: 6500000,
    rsi: 61.2,
    trend: 'BULLISH',
    signal: 'BUY',
    algoSetup: {
      name: 'BankNifty Sector Leader Continuation',
      description: 'Persistent institutional buying across private banks, clean higher highs on 15m.',
      triggerCondition: 'Enter above ₹1,286 on strong tick volume.',
      triggerTime: 'Active now (10:00 AM - 12:00 PM IST)',
      entryZone: {
        min: 1282.00,
        max: 1287.00,
        ideal: 1285.00,
      },
      target1: {
        price: 1308.00,
        gainPercent: 1.74,
        sharesToExitPercent: 50,
        instruction: 'Book 50% profit. Shift Stop Loss to ₹1,285.00.',
      },
      target2: {
        price: 1328.00,
        gainPercent: 3.30,
        sharesToExitPercent: 30,
        instruction: 'Book 30% profit. Trail Stop Loss to ₹1,308.',
      },
      target3Runner: {
        price: 1350.00,
        gainPercent: 5.01,
        sharesToExitPercent: 20,
        instruction: 'Trail with 20 EMA.',
      },
      stopLoss: {
        price: 1272.00,
        riskPercent: 1.05,
        timingRule: 'KAB LAGANA HAI: Order execute hote hi ₹1,272 pe SL order lagao bina kisi deri ke.',
        trailingRule: 'Target 1 aane par SL cost pe le aao.',
        invalidation: '15m close below ₹1,272.',
      },
      riskRewardRatio: '1 : 2.80',
      winProbability: 80.8,
      sector: 'Banking & Financials',
    },
    candles: generateCandles(1285.60, 0.0031, 0.0012),
  },
  {
    symbol: 'TSLA',
    name: 'Tesla, Inc.',
    exchange: 'NASDAQ',
    price: 324.50,
    prevClose: 335.00,
    change: -10.50,
    changePercent: -3.13,
    dayHigh: 337.00,
    dayLow: 321.00,
    volume: 64000000,
    avgVolume: 51000000,
    rsi: 38.5,
    trend: 'BEARISH',
    signal: 'SELL_SHORT',
    algoSetup: {
      name: 'Institutional Distribution & VWAP Breakdown',
      description: 'Heavy institutional block sell orders, failure to hold above 50-day moving average.',
      triggerCondition: 'Short on breakdown below $322.00 or pullback to $326.00.',
      triggerTime: 'US Session intraday breakdown',
      entryZone: {
        min: 324.00,
        max: 326.50,
        ideal: 325.00,
      },
      target1: {
        price: 314.00,
        gainPercent: 3.24,
        sharesToExitPercent: 50,
        instruction: 'Cover 50% short profit. Shift Stop Loss to $325.00.',
      },
      target2: {
        price: 304.00,
        gainPercent: 6.32,
        sharesToExitPercent: 30,
        instruction: 'Cover 30% short profit. Trail SL to $314.',
      },
      target3Runner: {
        price: 292.00,
        gainPercent: 10.02,
        sharesToExitPercent: 20,
        instruction: 'Hold runner short position until reversal.',
      },
      stopLoss: {
        price: 331.00,
        riskPercent: 2.00,
        timingRule: 'KAB LAGANA HAI: Short position enter hote hi immediately $331.00 ka buy stop order lagao.',
        trailingRule: 'T1 aate hi SL cost ($325) par le aao.',
        invalidation: 'Reclaiming $331 with high volume invalidates the short bias.',
      },
      riskRewardRatio: '1 : 2.80',
      winProbability: 77.2,
      sector: 'Automotive & Clean Energy',
    },
    candles: generateCandles(324.50, 0.006, -0.0022),
  }
];
