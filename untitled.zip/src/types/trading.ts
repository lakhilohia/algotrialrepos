export type SignalType = 'STRONG_BUY' | 'BUY' | 'WAIT_PULLBACK' | 'SELL_SHORT' | 'NEUTRAL';

export interface Candle {
  time: string;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ema20?: number;
  ema50?: number;
}

export interface AlgoSetup {
  name: string;
  description: string;
  triggerCondition: string;
  triggerTime: string;
  entryZone: {
    min: number;
    max: number;
    ideal: number;
  };
  target1: {
    price: number;
    gainPercent: number;
    sharesToExitPercent: number; // e.g. 50%
    instruction: string;
  };
  target2: {
    price: number;
    gainPercent: number;
    sharesToExitPercent: number; // e.g. 30%
    instruction: string;
  };
  target3Runner: {
    price: number;
    gainPercent: number;
    sharesToExitPercent: number; // 20%
    instruction: string;
  };
  stopLoss: {
    price: number;
    riskPercent: number;
    timingRule: string; // "KAB LAGANA HAI: Order execute hote hi turant system me hard stop-loss trigger set karein."
    trailingRule: string; // "Jab Target 1 hit ho jaye, SL ko turant Entry Price (Cost) pe shift karein (Zero-Risk Trade)."
    invalidation: string;
  };
  riskRewardRatio: string;
  winProbability: number;
  sector: string;
}

export interface StockItem {
  symbol: string;
  name: string;
  exchange: 'NSE' | 'NASDAQ' | 'BSE';
  price: number;
  prevClose: number;
  change: number;
  changePercent: number;
  dayHigh: number;
  dayLow: number;
  volume: number;
  avgVolume: number;
  rsi: number;
  trend: 'BULLISH' | 'STRONGLY_BULLISH' | 'SIDEWAYS' | 'BEARISH';
  signal: SignalType;
  algoSetup: AlgoSetup;
  candles: Candle[];
}

export interface Position {
  id: string;
  symbol: string;
  type: 'BUY' | 'SHORT';
  entryPrice: number;
  entryTime: string;
  quantity: number;
  currentPrice: number;
  stopLoss: number;
  target1: number;
  target2: number;
  target3: number;
  target1Hit: boolean;
  target2Hit: boolean;
  trailingSlActive: boolean;
  unrealizedPnl: number;
  unrealizedPnlPercent: number;
  status: 'OPEN' | 'CLOSED_PROFIT' | 'CLOSED_SL' | 'CLOSED_PARTIAL';
  exitPrice?: number;
  exitTime?: string;
  realizedPnl?: number;
  log: string[];
}

export interface AIAuditResult {
  verdict: SignalType;
  confidenceScore: number;
  entryTiming: string;
  entryPriceZone: string;
  target1: {
    price: number;
    percentGain: number;
    action: string;
  };
  target2: {
    price: number;
    percentGain: number;
    action: string;
  };
  target3Runner: {
    price: number;
    percentGain: number;
    action: string;
  };
  stopLoss: {
    price: number;
    percentRisk: number;
    kabLaganaHai: string;
    invalidationRule: string;
  };
  riskRewardRatio: string;
  institutionalReasoning: string;
  hinglishSummary: string;
}
