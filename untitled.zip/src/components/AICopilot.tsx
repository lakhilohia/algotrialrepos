import React, { useState } from 'react';
import { Sparkles, Send, Bot, User, ShieldAlert, Target, Clock, ArrowRight } from 'lucide-react';
import { StockItem } from '../types/trading';

interface AICopilotProps {
  selectedStock: StockItem;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  time: string;
}

export const AICopilot: React.FC<AICopilotProps> = ({ selectedStock }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: `Namaste! I am the StrykeX Institutional Algo Copilot.
I am here to guide you with mathematically proven institutional rules:
1. Exact Entry Trigger & Time window (Kab kharidna hai).
2. Multi-tier Profit Booking targets (Kab profit book karna hai - 50%, 30%, 20% rule).
3. Stop-Loss timing & Trailing mechanics (Kab aur kaise Stop Loss lagana hai).

Ask me any question in Hindi, Hinglish, or English about ${selectedStock.symbol} or general market strategies!`,
      time: 'Just now',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sampleQuestions = [
    `Kab stop loss lagana chahiye aur T1 ke baad kya karein?`,
    `Audit ${selectedStock.symbol}: Exact Entry, Targets & SL`,
    `Why should I book 50% profit at Target 1?`,
    `What is the best time of day to take intraday trades?`,
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || loading) return;

    const userMsg: Message = {
      role: 'user',
      content: query,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/chat-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          activeStock: {
            symbol: selectedStock.symbol,
            name: selectedStock.name,
            price: selectedStock.price,
            signal: selectedStock.signal,
            entry: selectedStock.algoSetup.entryZone.ideal,
            target1: selectedStock.algoSetup.target1.price,
            target2: selectedStock.algoSetup.target2.price,
            sl: selectedStock.algoSetup.stopLoss.price,
          },
        }),
      });

      const data = await res.json();
      if (data.success && data.answer) {
        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: data.answer,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: 'Service is temporarily busy. Please retry in a moment.',
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: 'Unable to reach the AI server. Please make sure network connection is active.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      {/* Top Banner */}
      <div className="p-4 rounded-xl bg-[#0D121F] border border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">
              StrykeX Institutional AI Advisor
            </h3>
            <p className="text-xs text-slate-400">
              Active Stock Context: <strong className="text-emerald-400 font-mono">{selectedStock.symbol}</strong> (₹{selectedStock.price})
            </p>
          </div>
        </div>
      </div>

      {/* Suggested Quick Questions */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-500 font-mono text-[11px] uppercase tracking-wider shrink-0">
          Suggested:
        </span>
        {sampleQuestions.map((q, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(q)}
            className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-purple-500/40 text-xs whitespace-nowrap transition-all shrink-0 cursor-pointer"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Chat Messages Container */}
      <div className="h-[440px] overflow-y-auto p-4 rounded-xl bg-[#0A0E17] border border-slate-800 space-y-4">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex items-start gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.role === 'assistant' && (
              <div className="w-8 h-8 rounded-lg bg-purple-600/20 border border-purple-500/30 flex items-center justify-center shrink-0 text-purple-400">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[80%] p-4 rounded-xl text-xs leading-relaxed ${
                m.role === 'user'
                  ? 'bg-emerald-600/20 border border-emerald-500/30 text-white font-mono'
                  : 'bg-slate-900/90 border border-slate-800 text-slate-200'
              }`}
            >
              <div className="whitespace-pre-line">{m.content}</div>
              <div className="text-[10px] text-slate-500 mt-2 text-right font-mono">{m.time}</div>
            </div>

            {m.role === 'user' && (
              <div className="w-8 h-8 rounded-lg bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center shrink-0 text-emerald-400">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-xs text-purple-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
            Generating institutional response...
          </div>
        )}
      </div>

      {/* Input Box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="flex items-center gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask: 'Kab stop loss lagana hai?', 'Explain Target 1 partial booking', 'Audit INFY'..."
          className="flex-1 px-4 py-3 bg-[#0D121F] border border-slate-700 rounded-xl text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="px-5 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-mono text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-purple-600/20"
        >
          <span>Send</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
