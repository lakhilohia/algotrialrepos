import React, { useState } from 'react';
import { Search, Filter, ShieldAlert, Target, Clock, ArrowUpRight, TrendingUp } from 'lucide-react';
import { StockItem, SignalType } from '../types/trading';

interface SignalRadarProps {
  stocks: StockItem[];
  onSelectStock: (stock: StockItem) => void;
}

export const SignalRadar: React.FC<SignalRadarProps> = ({ stocks, onSelectStock }) => {
  const [filterSignal, setFilterSignal] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredStocks = stocks.filter((stock) => {
    const matchesFilter = filterSignal === 'ALL' || stock.signal === filterSignal;
    const matchesSearch =
      stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stock.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stock.algoSetup.sector.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-xl bg-[#0C101A] border border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
            Institutional Algo Signal Radar
          </h2>
          <p className="text-xs text-slate-400">
            Scanning 50+ institutional order blocks with real-time entry triggers and risk-reward calculation
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search symbol, sector..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-48 sm:w-60"
            />
          </div>

          {/* Filter tabs */}
          <div className="flex items-center bg-slate-900 rounded-lg p-0.5 border border-slate-800 text-xs font-mono">
            {['ALL', 'STRONG_BUY', 'BUY', 'WAIT_PULLBACK', 'SELL_SHORT'].map((sig) => (
              <button
                key={sig}
                onClick={() => setFilterSignal(sig)}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-all ${
                  filterSignal === sig
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {sig === 'ALL' ? 'All Signals' : sig.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Signals Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-[#0B0F19] shadow-xl">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-mono text-[11px] uppercase tracking-wider">
              <th className="py-3 px-4">Stock &amp; Price</th>
              <th className="py-3 px-4">Algo Signal</th>
              <th className="py-3 px-4">When to Invest (Entry &amp; Timing)</th>
              <th className="py-3 px-4">Target 1 &amp; 2 (Profit Booking)</th>
              <th className="py-3 px-4">Kab Stop Loss Lagana Hai</th>
              <th className="py-3 px-4">Win Prob / R:R</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {filteredStocks.map((stock) => {
              const setup = stock.algoSetup;
              const curr = stock.exchange === 'NASDAQ' ? '$' : '₹';
              return (
                <tr
                  key={stock.symbol}
                  className="hover:bg-slate-900/50 transition-colors group cursor-pointer"
                  onClick={() => onSelectStock(stock)}
                >
                  {/* Stock & CMP */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="font-bold text-white text-sm">{stock.symbol}</div>
                    <div className="text-[11px] text-slate-400">{stock.name}</div>
                    <div className="text-xs mt-0.5">
                      <strong className="text-white">{curr}{stock.price.toFixed(1)}</strong>
                      <span className={`ml-1.5 text-[11px] ${stock.change >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {stock.change >= 0 ? '+' : ''}{stock.changePercent}%
                      </span>
                    </div>
                  </td>

                  {/* Signal Badge */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        stock.signal === 'STRONG_BUY'
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                          : stock.signal === 'BUY'
                          ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                          : stock.signal === 'WAIT_PULLBACK'
                          ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {stock.signal.replace('_', ' ')}
                    </span>
                    <div className="text-[10px] text-slate-400 mt-1 max-w-[140px] truncate font-sans">
                      {setup.name}
                    </div>
                  </td>

                  {/* When to Invest */}
                  <td className="py-3.5 px-4 min-w-[200px]">
                    <div className="text-cyan-400 font-bold">
                      Zone: {curr}{setup.entryZone.min} - {curr}{setup.entryZone.max}
                    </div>
                    <div className="text-[11px] text-slate-300 font-sans mt-0.5 leading-snug">
                      {setup.triggerTime}
                    </div>
                  </td>

                  {/* Target 1 & 2 */}
                  <td className="py-3.5 px-4 min-w-[200px]">
                    <div className="text-emerald-400 font-semibold">
                      T1 (50%): {curr}{setup.target1.price} (+{setup.target1.gainPercent}%)
                    </div>
                    <div className="text-emerald-300 text-[11px]">
                      T2 (30%): {curr}{setup.target2.price} (+{setup.target2.gainPercent}%)
                    </div>
                  </td>

                  {/* Kab Stop Loss Lagana Hai */}
                  <td className="py-3.5 px-4 min-w-[220px]">
                    <div className="text-rose-400 font-bold">
                      Hard SL: {curr}{setup.stopLoss.price} (-{setup.stopLoss.riskPercent}%)
                    </div>
                    <div className="text-[10px] text-slate-400 font-sans mt-0.5 leading-tight">
                      Order hote hi turant lagao; T1 aate hi SL cost pe shift karo.
                    </div>
                  </td>

                  {/* Win Prob & R:R */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="text-emerald-400 font-bold">{setup.winProbability}%</div>
                    <div className="text-slate-400 text-[11px]">R:R {setup.riskRewardRatio}</div>
                  </td>

                  {/* Action */}
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectStock(stock);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 text-slate-200 text-xs font-semibold transition-all inline-flex items-center gap-1 font-mono"
                    >
                      Trade
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
