import React from 'react';
import { ShieldCheck, Activity, Zap, TrendingUp, Sparkles, BookOpen, Layers } from 'lucide-react';

interface HeaderProps {
  activeTab: 'terminal' | 'radar' | 'guide' | 'backtest' | 'copilot';
  setActiveTab: (tab: 'terminal' | 'radar' | 'guide' | 'backtest' | 'copilot') => void;
  openPositionsCount: number;
  totalPnl: number;
  autopilotActive: boolean;
  setAutopilotActive: React.Dispatch<React.SetStateAction<boolean>>;
  onOpenPositions: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  openPositionsCount,
  totalPnl,
  autopilotActive,
  setAutopilotActive,
  onOpenPositions,
}) => {
  return (
    <header className="sticky top-0 z-50 flex items-center justify-between gap-8 px-6 py-3.5 bg-[#0A0E17]/95 backdrop-blur-md border-b border-slate-800/80">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <a
          href="#terminal"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('terminal');
          }}
          className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-white whitespace-nowrap"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Zap className="w-4 h-4 text-slate-950 fill-slate-950" />
          </div>
          <span className="font-extrabold tracking-tight">
            STRYKE<span className="text-emerald-400">X</span>
          </span>
          <span className="text-[11px] font-mono uppercase px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
            ALGO AI
          </span>
        </a>
      </div>

      {/* Zone 2: Navigation Links (Single Line, 4-5 Clean Links) */}
      <nav className="hidden md:flex items-center gap-1.5 lg:gap-3 text-xs font-semibold text-slate-400">
        <button
          onClick={() => setActiveTab('terminal')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'terminal'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          AI Terminal
        </button>

        <button
          onClick={() => setActiveTab('radar')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'radar'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
          Live Radar
        </button>

        <button
          onClick={() => setActiveTab('guide')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'guide'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          Profit &amp; Stop Loss Guide
        </button>

        <button
          onClick={() => setActiveTab('backtest')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'backtest'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-indigo-400" />
          Autopilot &amp; Backtest
        </button>

        <button
          onClick={() => setActiveTab('copilot')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'copilot'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          Ask AI Advisor
        </button>
      </nav>

      {/* Zone 3: 1 Primary Action Area */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={() => setAutopilotActive(!autopilotActive)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all whitespace-nowrap shrink-0 border ${
            autopilotActive
              ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
              : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200'
          }`}
          title="Autopilot automatically trails stop-loss and locks partial profits at Target 1 & 2"
        >
          <span className={`w-2 h-2 rounded-full ${autopilotActive ? 'bg-emerald-400' : 'bg-slate-500'}`} />
          Autopilot: {autopilotActive ? 'ACTIVE (0.3ms)' : 'STANDBY'}
        </button>

        <button
          onClick={onOpenPositions}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-xs font-mono whitespace-nowrap shrink-0 transition-colors"
        >
          <span className="text-slate-400">Positions ({openPositionsCount})</span>
          <span className={`font-semibold ${totalPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalPnl >= 0 ? '+' : ''}₹{totalPnl.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </button>
      </div>
    </header>
  );
};
