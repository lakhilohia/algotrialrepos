import React from 'react';
import { X, TrendingUp, ShieldAlert, Target, CheckCircle2, AlertOctagon, RotateCcw } from 'lucide-react';
import { Position } from '../types/trading';
import confetti from 'canvas-confetti';

interface LivePositionTrackerProps {
  isOpen: boolean;
  onClose: () => void;
  positions: Position[];
  onClosePosition: (id: string) => void;
  onSimulateTargetHit: (id: string, targetNum: 1 | 2) => void;
  onSimulateSlHit: (id: string) => void;
}

export const LivePositionTracker: React.FC<LivePositionTrackerProps> = ({
  isOpen,
  onClose,
  positions,
  onClosePosition,
  onSimulateTargetHit,
  onSimulateSlHit,
}) => {
  if (!isOpen) return null;

  const openPositions = positions.filter((p) => p.status === 'OPEN' || p.status === 'CLOSED_PARTIAL');
  const closedPositions = positions.filter((p) => p.status === 'CLOSED_PROFIT' || p.status === 'CLOSED_SL');

  const totalUnrealizedPnl = openPositions.reduce((acc, p) => acc + p.unrealizedPnl, 0);
  const totalRealizedPnl = closedPositions.reduce((acc, p) => acc + (p.realizedPnl || 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#0E131F] rounded-xl border border-slate-700/80 shadow-2xl p-6 text-slate-200 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Live Portfolio &amp; Active Positions ({openPositions.length})
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Real-time trailing stop-loss &amp; multi-tier profit execution engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right font-mono text-xs">
              <div className="text-slate-400 text-[10px]">Unrealized P&amp;L</div>
              <div className={`text-base font-bold ${totalUnrealizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {totalUnrealizedPnl >= 0 ? '+' : ''}₹{totalUnrealizedPnl.toFixed(2)}
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Positions Content */}
        <div className="overflow-y-auto space-y-4 pr-1 flex-1">
          {openPositions.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500">
                <Target className="w-6 h-6" />
              </div>
              <div className="text-sm font-semibold text-slate-300">No Open Positions Currently</div>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Go to the AI Terminal, review a stock signal, and click "Calculate Position Size &amp; Execute" to enter an algorithmic trade.
              </p>
            </div>
          ) : (
            openPositions.map((pos) => {
              return (
                <div
                  key={pos.id}
                  className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3 font-mono text-xs"
                >
                  {/* Top row */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-white text-sm">{pos.symbol}</span>
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                        {pos.type} {pos.quantity} QTY
                      </span>
                      {pos.trailingSlActive && (
                        <span className="px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[10px] font-bold">
                          TRAILING SL TO COST ACTIVE (RISK-FREE)
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-slate-400">P&amp;L:</span>
                      <span
                        className={`text-sm font-extrabold ${
                          pos.unrealizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {pos.unrealizedPnl >= 0 ? '+' : ''}₹{pos.unrealizedPnl.toFixed(2)} ({pos.unrealizedPnlPercent >= 0 ? '+' : ''}{pos.unrealizedPnlPercent.toFixed(2)}%)
                      </span>
                    </div>
                  </div>

                  {/* Execution Levels Strip */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                    <div className="p-2 rounded bg-slate-950 border border-slate-800">
                      <span className="text-slate-500 block">Entry Price:</span>
                      <span className="text-white font-bold">₹{pos.entryPrice.toFixed(2)}</span>
                    </div>

                    <div className="p-2 rounded bg-slate-950 border border-slate-800">
                      <span className="text-slate-500 block">Current Price:</span>
                      <span className="text-emerald-300 font-bold">₹{pos.currentPrice.toFixed(2)}</span>
                    </div>

                    <div className="p-2 rounded bg-rose-950/20 border border-rose-900/30">
                      <span className="text-rose-400 block font-semibold">Active Stop Loss:</span>
                      <span className="text-rose-300 font-bold">₹{pos.stopLoss.toFixed(2)}</span>
                    </div>

                    <div className="p-2 rounded bg-emerald-950/20 border border-emerald-900/30">
                      <span className="text-emerald-400 block font-semibold">Targets:</span>
                      <span className="text-emerald-300 font-bold">
                        T1: ₹{pos.target1} | T2: ₹{pos.target2}
                      </span>
                    </div>
                  </div>

                  {/* Interactive Test Action Controls */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/60">
                    <div className="flex items-center gap-2">
                      <span className="text-slate-500 text-[10px]">Simulate Action:</span>

                      {!pos.target1Hit && (
                        <button
                          onClick={() => onSimulateTargetHit(pos.id, 1)}
                          className="px-2.5 py-1 rounded bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold"
                          title="Simulates price touching Target 1: Books 50% profit & trails SL to Cost"
                        >
                          Hit Target 1 (Book 50% &amp; Trail SL)
                        </button>
                      )}

                      {pos.target1Hit && !pos.target2Hit && (
                        <button
                          onClick={() => onSimulateTargetHit(pos.id, 2)}
                          className="px-2.5 py-1 rounded bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/40 text-cyan-300 text-[10px] font-bold"
                          title="Simulates price touching Target 2: Books 30% profit"
                        >
                          Hit Target 2 (Book 30%)
                        </button>
                      )}

                      <button
                        onClick={() => onSimulateSlHit(pos.id)}
                        className="px-2.5 py-1 rounded bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 text-[10px] font-bold"
                        title="Simulates price hitting Stop Loss: Cuts loss at predetermined risk"
                      >
                        Hit Stop Loss
                      </button>
                    </div>

                    <button
                      onClick={() => onClosePosition(pos.id)}
                      className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition-colors"
                    >
                      Close Market
                    </button>
                  </div>

                  {/* Audit Logs */}
                  {pos.log && pos.log.length > 0 && (
                    <div className="p-2 rounded bg-slate-950/80 text-[10px] text-slate-400 space-y-0.5">
                      {pos.log.map((lg, i) => (
                        <div key={i} className="flex items-center gap-1.5">
                          <span className="text-emerald-500 font-bold">›</span>
                          <span>{lg}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}

          {/* Closed Trades History */}
          {closedPositions.length > 0 && (
            <div className="pt-4 border-t border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                <span>Closed Positions History ({closedPositions.length})</span>
                <span>
                  Realized P&amp;L:{' '}
                  <strong className={totalRealizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                    {totalRealizedPnl >= 0 ? '+' : ''}₹{totalRealizedPnl.toFixed(2)}
                  </strong>
                </span>
              </div>

              <div className="space-y-1.5 font-mono text-xs">
                {closedPositions.map((cp) => (
                  <div
                    key={cp.id}
                    className="p-2.5 rounded-lg bg-slate-900/50 border border-slate-800/80 flex items-center justify-between text-[11px]"
                  >
                    <div>
                      <strong className="text-white">{cp.symbol}</strong> ({cp.quantity} shares) · Entry: ₹{cp.entryPrice.toFixed(1)} · Exit: ₹{cp.exitPrice?.toFixed(1)}
                    </div>
                    <div className={cp.realizedPnl && cp.realizedPnl >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {cp.realizedPnl && cp.realizedPnl >= 0 ? '+' : ''}₹{cp.realizedPnl?.toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
