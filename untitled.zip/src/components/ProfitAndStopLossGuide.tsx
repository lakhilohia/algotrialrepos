import React, { useState } from 'react';
import {
  ShieldAlert,
  Target,
  Clock,
  ArrowRight,
  CheckCircle2,
  AlertOctagon,
  Percent,
  Sliders,
  Sparkles,
} from 'lucide-react';

export const ProfitAndStopLossGuide: React.FC = () => {
  // Interactive Simulator state
  const [stockPrice, setStockPrice] = useState<number>(2940);
  const [accountCapital, setAccountCapital] = useState<number>(100000);
  const [riskPercent, setRiskPercent] = useState<number>(1.0); // 1%
  const [slPercent, setSlPercent] = useState<number>(1.2); // 1.2% SL
  const [t1Percent, setT1Percent] = useState<number>(2.0); // 2% T1
  const [t2Percent, setT2Percent] = useState<number>(4.0); // 4% T2

  // Math
  const maxRiskAmount = (accountCapital * riskPercent) / 100;
  const slPrice = Number((stockPrice * (1 - slPercent / 100)).toFixed(1));
  const t1Price = Number((stockPrice * (1 + t1Percent / 100)).toFixed(1));
  const t2Price = Number((stockPrice * (1 + t2Percent / 100)).toFixed(1));

  const riskPerShare = Math.abs(stockPrice - slPrice) || 1;
  const calculatedShares = Math.max(1, Math.floor(maxRiskAmount / riskPerShare));
  const totalMarginRequired = calculatedShares * stockPrice;

  const maxLoss = calculatedShares * riskPerShare;
  const t1Gain = calculatedShares * 0.5 * (t1Price - stockPrice);
  const t2Gain = calculatedShares * 0.3 * (t2Price - stockPrice);
  const totalPotentialProfit = t1Gain + t2Gain + calculatedShares * 0.2 * (t2Price * 1.03 - stockPrice);
  const rrRatio = (totalPotentialProfit / maxLoss).toFixed(2);

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Title & Introduction */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0E1524] via-[#0D121F] to-[#0A0E17] border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              Institutional Algo Playbook: Entry, Profit Booking &amp; Stop Loss
            </h1>
            <p className="text-xs text-slate-400 font-mono">
              The exact rules institutional algorithms follow to protect capital and maximize returns
            </p>
          </div>
        </div>
      </div>

      {/* The 3 Core Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Pillar 1: WHEN TO INVEST & TIME */}
        <div className="p-5 rounded-xl bg-[#0D121F] border border-cyan-500/30 shadow-lg flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs uppercase font-bold">
              <Clock className="w-4 h-4 text-cyan-400" />
              Pillar 1: When to Invest
            </div>
            <h3 className="text-lg font-bold text-white tracking-tight">
              Kab Kharidna Hai &amp; Timing
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">Avoid 9:15 - 9:30 AM:</strong> The opening 15 minutes are retail trap zones with wide bid-ask spreads. Let initial noise settle.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">Prime Window (9:45 - 11:15 AM):</strong> High institutional order flow. Look for 15-min candle body close above resistance with volume &gt; 1.5x average.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">Afternoon Window (1:30 - 2:45 PM):</strong> European market sync and intraday continuation moves.
                </span>
              </li>
            </ul>
          </div>
          <div className="p-3 rounded-lg bg-cyan-950/30 border border-cyan-800/40 text-[11px] font-mono text-cyan-200">
            <strong>Rule:</strong> Never buy at market high. Always wait for a retest of 20 EMA or breakout confirmation.
          </div>
        </div>

        {/* Pillar 2: KAB STOP LOSS LAGANA HAI */}
        <div className="p-5 rounded-xl bg-[#0D121F] border border-rose-500/30 shadow-lg flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-rose-400 font-mono text-xs uppercase font-bold">
              <AlertOctagon className="w-4 h-4 text-rose-400" />
              Pillar 2: Stop Loss Timing
            </div>
            <h3 className="text-lg font-bold text-white tracking-tight">
              Kab Stop Loss Lagana Hai
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">Timing: Immediately on Entry!</strong> Buy order fill hote hi 5 SECONDS ke andar broker terminal par Hard Stop Loss lagana mandatory hai.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">No Mental Stop Loss:</strong> "Jab girega tab dekhunga" is why 90% retail traders blow up. Algorithms execute hard orders.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">Trailing SL Mechanics:</strong> Jab Target 1 hit ho jaye, Stop Loss ko turant Cost (Entry Price) par le aao. Trade 100% Risk-Free ho gaya!
                </span>
              </li>
            </ul>
          </div>
          <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-800/40 text-[11px] font-mono text-rose-200">
            <strong>Rule:</strong> Never risk more than 1% to 1.5% of total capital on a single stock trade.
          </div>
        </div>

        {/* Pillar 3: WHEN TO EXIT WITH PROFIT */}
        <div className="p-5 rounded-xl bg-[#0D121F] border border-emerald-500/30 shadow-lg flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs uppercase font-bold">
              <Target className="w-4 h-4 text-emerald-400" />
              Pillar 3: Profit Booking
            </div>
            <h3 className="text-lg font-bold text-white tracking-tight">
              Profit Kab Book Karna Hai
            </h3>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">Target 1 (Book 50% Shares):</strong> Target 1 (usually +1.5% to +2%) aate hi 50% quantity book karke cash in bank lock karo.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">Target 2 (Book 30% Shares):</strong> Target 2 (+3% to +4.5%) hit hote hi 30% exit karo, aur SL ko Target 1 pe lock karo.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                <span>
                  <strong className="text-white">Runner 20% (The Moonbag):</strong> Remaining 20% quantity ko 20 EMA ya Supertrend ke sath trail karte chalo jab tak reversal candle na bane.
                </span>
              </li>
            </ul>
          </div>
          <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-800/40 text-[11px] font-mono text-emerald-200">
            <strong>Rule:</strong> Green trades ko kabhi red me close mat hone do. T1 aate hi Cost SL lagana zaroori hai.
          </div>
        </div>
      </div>

      {/* Interactive Simulator: "Test Your Trade Setup" */}
      <div className="p-6 rounded-2xl bg-[#0C101A] border border-slate-800 shadow-xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Interactive Institutional Trade Calculator
              </h2>
              <p className="text-xs text-slate-400">
                Adjust capital, entry, and stop loss to see exact quantity, risk control, and profit targets
              </p>
            </div>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700">
            Live Math Engine
          </span>
        </div>

        {/* Input Sliders */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Trading Capital:</span>
              <strong className="text-white">₹{accountCapital.toLocaleString()}</strong>
            </div>
            <input
              type="range"
              min="20000"
              max="1000000"
              step="10000"
              value={accountCapital}
              onChange={(e) => setAccountCapital(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Stock Price:</span>
              <strong className="text-white">₹{stockPrice.toLocaleString()}</strong>
            </div>
            <input
              type="range"
              min="100"
              max="5000"
              step="50"
              value={stockPrice}
              onChange={(e) => setStockPrice(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Max Risk per Trade (%):</span>
              <strong className="text-amber-400">{riskPercent}% (₹{maxRiskAmount.toLocaleString()})</strong>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.5"
              step="0.1"
              value={riskPercent}
              onChange={(e) => setRiskPercent(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Trade Execution Plan Output Box */}
        <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-4 font-mono text-xs">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <span className="text-slate-400 text-[11px] block">Calculated Quantity:</span>
              <span className="text-xl font-extrabold text-emerald-400">{calculatedShares} Shares</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">₹{totalMarginRequired.toLocaleString()} capital</span>
            </div>

            <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-800/40">
              <span className="text-rose-400 text-[11px] block font-bold">Hard Stop Loss:</span>
              <span className="text-xl font-extrabold text-rose-300">₹{slPrice}</span>
              <span className="text-[10px] text-rose-400 block mt-0.5">Max Loss: -₹{maxLoss.toFixed(0)} ({riskPercent}%)</span>
            </div>

            <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-800/40">
              <span className="text-emerald-400 text-[11px] block font-bold">Target 1 (Book 50%):</span>
              <span className="text-xl font-extrabold text-emerald-300">₹{t1Price}</span>
              <span className="text-[10px] text-emerald-400 block mt-0.5">Profit: +₹{t1Gain.toFixed(0)} (+{t1Percent}%)</span>
            </div>

            <div className="p-3 rounded-lg bg-cyan-950/30 border border-cyan-800/40">
              <span className="text-cyan-400 text-[11px] block font-bold">Target 2 (Book 30%):</span>
              <span className="text-xl font-extrabold text-cyan-300">₹{t2Price}</span>
              <span className="text-[10px] text-cyan-400 block mt-0.5">Profit: +₹{t2Gain.toFixed(0)} (+{t2Percent}%)</span>
            </div>
          </div>

          {/* Outcome bar */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-200">
                Setup Risk-to-Reward: <strong className="text-emerald-400 font-bold">1 : {rrRatio}</strong>
              </span>
            </div>
            <div className="text-slate-400 text-[11px]">
              Expected Return on ₹{maxLoss.toFixed(0)} Risk: <strong className="text-emerald-400 font-bold">+₹{totalPotentialProfit.toFixed(0)}</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
