import React, { useState, useRef } from 'react';
import { Candle, AlgoSetup } from '../types/trading';

interface CandlestickChartProps {
  candles: Candle[];
  symbol: string;
  currencySymbol: string;
  currentPrice: number;
  algoSetup: AlgoSetup;
  timeframe: string;
  setTimeframe: (tf: string) => void;
}

export const CandlestickChart: React.FC<CandlestickChartProps> = ({
  candles,
  symbol,
  currencySymbol,
  currentPrice,
  algoSetup,
  timeframe,
  setTimeframe,
}) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [showEma, setShowEma] = useState(true);
  const [showLevels, setShowLevels] = useState(true);
  const [showVolume, setShowVolume] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  if (!candles || candles.length === 0) {
    return <div className="h-96 flex items-center justify-center text-slate-500 font-mono">Loading market data...</div>;
  }

  // Calculate scales
  const prices = candles.flatMap((c) => [c.high, c.low]);
  if (showLevels) {
    prices.push(algoSetup.target1.price, algoSetup.target2.price, algoSetup.stopLoss.price, algoSetup.entryZone.ideal);
  }

  const minPrice = Math.min(...prices) * 0.998;
  const maxPrice = Math.max(...prices) * 1.002;
  const priceRange = maxPrice - minPrice || 1;

  const maxVolume = Math.max(...candles.map((c) => c.volume)) || 1;

  // Viewport dimensions
  const width = 850;
  const height = 480;
  const paddingRight = 85;
  const paddingLeft = 15;
  const paddingTop = 25;
  const paddingBottom = 45;

  const chartWidth = width - paddingLeft - paddingRight;
  const chartHeight = height - paddingTop - paddingBottom;

  const getY = (price: number) => {
    return paddingTop + chartHeight - ((price - minPrice) / priceRange) * chartHeight;
  };

  const candleSpacing = chartWidth / candles.length;
  const candleWidth = Math.max(2, candleSpacing * 0.7);

  // SVG path for 20 EMA & 50 EMA
  const ema20Path = candles
    .map((c, i) => {
      if (!c.ema20) return '';
      const x = paddingLeft + i * candleSpacing + candleSpacing / 2;
      const y = getY(c.ema20);
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    })
    .filter(Boolean)
    .join(' ');

  const ema50Path = candles
    .map((c, i) => {
      if (!c.ema50) return '';
      const x = paddingLeft + i * candleSpacing + candleSpacing / 2;
      const y = getY(c.ema50);
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    })
    .filter(Boolean)
    .join(' ');

  // Active candle for HUD
  const activeCandle = hoverIndex !== null && candles[hoverIndex] ? candles[hoverIndex] : candles[candles.length - 1];

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!containerRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - paddingLeft;
    const index = Math.floor(x / candleSpacing);
    if (index >= 0 && index < candles.length) {
      setHoverIndex(index);
    }
  };

  const handleMouseLeave = () => {
    setHoverIndex(null);
  };

  // Price grid ticks
  const priceTicks = [
    minPrice,
    minPrice + priceRange * 0.25,
    minPrice + priceRange * 0.5,
    minPrice + priceRange * 0.75,
    maxPrice,
  ];

  return (
    <div ref={containerRef} className="flex flex-col bg-[#0B0F19] rounded-xl border border-slate-800/80 overflow-hidden shadow-xl">
      {/* Chart Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-slate-900/60 border-b border-slate-800/80 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 font-mono text-slate-300">
            <span className="font-bold text-white text-sm">{symbol}</span>
            <span className="text-slate-500">·</span>
            <span className="text-emerald-400 font-semibold">{currencySymbol}{currentPrice.toFixed(2)}</span>
          </div>

          {/* Timeframe selector */}
          <div className="flex items-center bg-slate-800/90 rounded-md p-0.5 border border-slate-700/60">
            {['1m', '5m', '15m', '1h', '1D'].map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono font-medium transition-colors ${
                  timeframe === tf
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf} {tf === '15m' && <span className="text-[9px] uppercase font-bold ml-0.5">(Algo)</span>}
              </button>
            ))}
          </div>
        </div>

        {/* Indicator Toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowLevels(!showLevels)}
            className={`px-2.5 py-1 rounded text-[11px] font-mono font-medium border transition-colors ${
              showLevels
                ? 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30'
                : 'text-slate-500 border-slate-800 hover:text-slate-400'
            }`}
          >
            Algo Levels (Entry/SL/TP)
          </button>

          <button
            onClick={() => setShowEma(!showEma)}
            className={`px-2.5 py-1 rounded text-[11px] font-mono font-medium border transition-colors ${
              showEma
                ? 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                : 'text-slate-500 border-slate-800 hover:text-slate-400'
            }`}
          >
            EMA (20/50)
          </button>

          <button
            onClick={() => setShowVolume(!showVolume)}
            className={`px-2.5 py-1 rounded text-[11px] font-mono font-medium border transition-colors ${
              showVolume
                ? 'bg-slate-700/50 text-slate-300 border-slate-600'
                : 'text-slate-500 border-slate-800 hover:text-slate-400'
            }`}
          >
            Volume
          </button>
        </div>
      </div>

      {/* OHLCV Telemetry HUD */}
      <div className="flex flex-wrap items-center gap-x-5 gap-y-1 px-4 py-1.5 bg-[#090D15] text-[11px] font-mono text-slate-400 border-b border-slate-800/40">
        <span>Time: <strong className="text-slate-200">{activeCandle.time}</strong></span>
        <span>O: <strong className="text-slate-200">{currencySymbol}{activeCandle.open.toFixed(2)}</strong></span>
        <span>H: <strong className="text-emerald-400">{currencySymbol}{activeCandle.high.toFixed(2)}</strong></span>
        <span>L: <strong className="text-rose-400">{currencySymbol}{activeCandle.low.toFixed(2)}</strong></span>
        <span>C: <strong className={activeCandle.close >= activeCandle.open ? 'text-emerald-400' : 'text-rose-400'}>
          {currencySymbol}{activeCandle.close.toFixed(2)}
        </strong></span>
        {activeCandle.ema20 && showEma && (
          <span className="text-blue-400">EMA20: <strong>{currencySymbol}{activeCandle.ema20.toFixed(2)}</strong></span>
        )}
        {activeCandle.ema50 && showEma && (
          <span className="text-amber-400">EMA50: <strong>{currencySymbol}{activeCandle.ema50.toFixed(2)}</strong></span>
        )}
        {showVolume && (
          <span>Vol: <strong className="text-slate-300">{(activeCandle.volume / 1000).toFixed(1)}k</strong></span>
        )}
      </div>

      {/* Candlestick SVG Canvas */}
      <div className="relative w-full overflow-hidden select-none">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto cursor-crosshair"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          <defs>
            <linearGradient id="volumeGreen" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10B981" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#10B981" stopOpacity="0.05" />
            </linearGradient>
            <linearGradient id="volumeRed" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F43F5E" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#F43F5E" stopOpacity="0.05" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          {priceTicks.map((price, idx) => {
            const y = getY(price);
            return (
              <g key={idx}>
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={width - paddingRight}
                  y2={y}
                  stroke="#1E293B"
                  strokeWidth="1"
                  strokeDasharray="4 4"
                />
                <text
                  x={width - paddingRight + 8}
                  y={y + 3.5}
                  fill="#64748B"
                  fontSize="10"
                  fontFamily="JetBrains Mono, monospace"
                  textAnchor="start"
                >
                  {currencySymbol}{price.toFixed(1)}
                </text>
              </g>
            );
          })}

          {/* Volume bars (bottom 25% of chart) */}
          {showVolume &&
            candles.map((c, i) => {
              const x = paddingLeft + i * candleSpacing + (candleSpacing - candleWidth) / 2;
              const volHeight = (c.volume / maxVolume) * (chartHeight * 0.22);
              const y = paddingTop + chartHeight - volHeight;
              const isGreen = c.close >= c.open;
              return (
                <rect
                  key={`vol-${i}`}
                  x={x}
                  y={y}
                  width={candleWidth}
                  height={volHeight}
                  fill={isGreen ? 'url(#volumeGreen)' : 'url(#volumeRed)'}
                />
              );
            })}

          {/* EMA Lines */}
          {showEma && ema50Path && (
            <path d={ema50Path} fill="none" stroke="#F59E0B" strokeWidth="1.5" strokeOpacity="0.75" />
          )}
          {showEma && ema20Path && (
            <path d={ema20Path} fill="none" stroke="#38BDF8" strokeWidth="1.75" />
          )}

          {/* Candlesticks */}
          {candles.map((c, i) => {
            const x = paddingLeft + i * candleSpacing + candleSpacing / 2;
            const openY = getY(c.open);
            const closeY = getY(c.close);
            const highY = getY(c.high);
            const lowY = getY(c.low);

            const isGreen = c.close >= c.open;
            const candleBodyY = Math.min(openY, closeY);
            const candleBodyHeight = Math.max(1.5, Math.abs(closeY - openY));
            const color = isGreen ? '#10B981' : '#F43F5E';

            return (
              <g key={`candle-${i}`}>
                {/* Wick */}
                <line
                  x1={x}
                  y1={highY}
                  x2={x}
                  y2={lowY}
                  stroke={color}
                  strokeWidth="1.2"
                />
                {/* Body */}
                <rect
                  x={x - candleWidth / 2}
                  y={candleBodyY}
                  width={candleWidth}
                  height={candleBodyHeight}
                  fill={color}
                  rx="1"
                />
              </g>
            );
          })}

          {/* Target 2 Line */}
          {showLevels && (
            <g>
              <line
                x1={paddingLeft}
                y1={getY(algoSetup.target2.price)}
                x2={width - paddingRight}
                y2={getY(algoSetup.target2.price)}
                stroke="#10B981"
                strokeWidth="1.5"
                strokeDasharray="5 3"
              />
              <rect
                x={width - paddingRight + 4}
                y={getY(algoSetup.target2.price) - 9}
                width={76}
                height={18}
                fill="#064E3B"
                rx="3"
              />
              <text
                x={width - paddingRight + 8}
                y={getY(algoSetup.target2.price) + 3}
                fill="#34D399"
                fontSize="9"
                fontWeight="bold"
                fontFamily="JetBrains Mono, monospace"
              >
                T2: {currencySymbol}{algoSetup.target2.price.toFixed(0)} (+{algoSetup.target2.gainPercent}%)
              </text>
            </g>
          )}

          {/* Target 1 Line */}
          {showLevels && (
            <g>
              <line
                x1={paddingLeft}
                y1={getY(algoSetup.target1.price)}
                x2={width - paddingRight}
                y2={getY(algoSetup.target1.price)}
                stroke="#059669"
                strokeWidth="1.5"
                strokeDasharray="4 2"
              />
              <rect
                x={width - paddingRight + 4}
                y={getY(algoSetup.target1.price) - 9}
                width={76}
                height={18}
                fill="#065F46"
                rx="3"
              />
              <text
                x={width - paddingRight + 8}
                y={getY(algoSetup.target1.price) + 3}
                fill="#6EE7B7"
                fontSize="9"
                fontWeight="bold"
                fontFamily="JetBrains Mono, monospace"
              >
                T1: {currencySymbol}{algoSetup.target1.price.toFixed(0)} (+{algoSetup.target1.gainPercent}%)
              </text>
            </g>
          )}

          {/* Entry Line */}
          {showLevels && (
            <g>
              <line
                x1={paddingLeft}
                y1={getY(algoSetup.entryZone.ideal)}
                x2={width - paddingRight}
                y2={getY(algoSetup.entryZone.ideal)}
                stroke="#06B6D4"
                strokeWidth="1.5"
                strokeDasharray="3 3"
              />
              <rect
                x={width - paddingRight + 4}
                y={getY(algoSetup.entryZone.ideal) - 9}
                width={76}
                height={18}
                fill="#164E63"
                rx="3"
              />
              <text
                x={width - paddingRight + 8}
                y={getY(algoSetup.entryZone.ideal) + 3}
                fill="#67E8F9"
                fontSize="9"
                fontWeight="bold"
                fontFamily="JetBrains Mono, monospace"
              >
                ENTRY: {currencySymbol}{algoSetup.entryZone.ideal.toFixed(0)}
              </text>
            </g>
          )}

          {/* Stop Loss Line */}
          {showLevels && (
            <g>
              <line
                x1={paddingLeft}
                y1={getY(algoSetup.stopLoss.price)}
                x2={width - paddingRight}
                y2={getY(algoSetup.stopLoss.price)}
                stroke="#EF4444"
                strokeWidth="1.75"
                strokeDasharray="5 3"
              />
              <rect
                x={width - paddingRight + 4}
                y={getY(algoSetup.stopLoss.price) - 9}
                width={76}
                height={18}
                fill="#7F1D1D"
                rx="3"
              />
              <text
                x={width - paddingRight + 8}
                y={getY(algoSetup.stopLoss.price) + 3}
                fill="#FCA5A5"
                fontSize="9"
                fontWeight="bold"
                fontFamily="JetBrains Mono, monospace"
              >
                SL: {currencySymbol}{algoSetup.stopLoss.price.toFixed(0)} (-{algoSetup.stopLoss.riskPercent}%)
              </text>
            </g>
          )}

          {/* Hover Crosshair */}
          {hoverIndex !== null && (
            <g>
              {/* Vertical line */}
              <line
                x1={paddingLeft + hoverIndex * candleSpacing + candleSpacing / 2}
                y1={paddingTop}
                x2={paddingLeft + hoverIndex * candleSpacing + candleSpacing / 2}
                y2={paddingTop + chartHeight}
                stroke="#94A3B8"
                strokeWidth="1"
                strokeDasharray="3 3"
              />
              {/* Horizontal line at hover candle close */}
              <line
                x1={paddingLeft}
                y1={getY(candles[hoverIndex].close)}
                x2={width - paddingRight}
                y2={getY(candles[hoverIndex].close)}
                stroke="#94A3B8"
                strokeWidth="1"
                strokeDasharray="3 3"
              />
            </g>
          )}
        </svg>
      </div>

      {/* Chart Footer Legend */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-4 py-2 bg-slate-900/50 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-cyan-400 inline-block"></span> Entry Zone
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-red-500 inline-block"></span> Stop Loss (Kab lagana: Order ke turant baad)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-emerald-400 inline-block"></span> Target 1 (50% Profit Book)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-emerald-300 inline-block"></span> Target 2 (30% Profit Book)
          </span>
        </div>
        <div className="text-slate-500">
          Risk/Reward: <span className="text-emerald-400 font-semibold">{algoSetup.riskRewardRatio}</span>
        </div>
      </div>
    </div>
  );
};
