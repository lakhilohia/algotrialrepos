import React, { useState } from 'react';
import { X, Calculator, ShieldAlert, ArrowRight, CheckCircle2 } from 'lucide-react';
import { StockItem } from '../types/trading';

interface PositionSizerModalProps {
  stock: StockItem;
  isOpen: boolean;
  onClose: () => void;
  onExecuteTrade: (quantity: number) => void;
}

export const PositionSizerModal: React.FC<PositionSizerModalProps> = ({
  stock,
  isOpen,
  onClose,
  onExecuteTrade,
}) => {
  const [totalCapital, setTotalCapital] = useState<number>(100000);
  const [riskPercent, setRiskPercent] = useState<number>(1.0); // 1% default

  if (!isOpen) return null;

  const entry = stock.algoSetup.entryZone.ideal;
  const sl = stock.algoSetup.stopLoss.price;
  const t1 = stock.algoSetup.target1.price;
  const t2 = stock.algoSetup.target2.price;

  const riskPerShare = Math.abs(entry - sl);
  const maxRiskAmount = (totalCapital * riskPercent) / 100;
  const calculatedQty = riskPerShare > 0 ? Math.floor(maxRiskAmount / riskPerShare) : 1;
  const finalQty = Math.max(1, calculatedQty);

  const totalRequiredCapital = finalQty * entry;
  const potentialLossAtSl = finalQty * riskPerShare;
  const profitAtT1 = (finalQty * 0.5) * (t1 - entry);
  const profitAtT2 = (finalQty * 0.3) * (t2 - entry);
  const currencySymbol = stock.exchange === 'NASDAQ' ? '$' : '₹';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0E131F] rounded-xl border border-slate-700/80 shadow-2xl p-6 text-slate-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-5">
          <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">Institutional Position Sizer</h3>
            <p className="text-xs text-slate-400">Never risk more than 1-2% of capital on any trade</p>
          </div>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-2 gap-4 mb-5">
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1.5">Total Trading Capital ({currencySymbol})</label>
            <input
              type="number"
              value={totalCapital}
              onChange={(e) => setTotalCapital(Math.max(1000, Number(e.target.value)))}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1.5">Max Risk Per Trade (%)</label>
            <div className="flex items-center gap-1.5">
              {[0.5, 1.0, 1.5, 2.0].map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRiskPercent(r)}
                  className={`flex-1 py-2 text-xs font-mono rounded-lg border transition-all ${
                    riskPercent === r
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
                      : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  {r}%
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Trade Math Breakdown */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3 mb-6 font-mono text-xs">
          <div className="flex justify-between items-center text-slate-300">
            <span>Stock &amp; Ideal Entry:</span>
            <span className="font-bold text-white">{stock.symbol} @ {currencySymbol}{entry.toFixed(2)}</span>
          </div>

          <div className="flex justify-between items-center text-rose-300">
            <span>Stop Loss Level (SL):</span>
            <span className="font-bold">{currencySymbol}{sl.toFixed(2)} (-{riskPerShare.toFixed(2)} / share)</span>
          </div>

          <div className="border-t border-slate-800 my-2 pt-2 flex justify-between items-center text-amber-300 font-semibold">
            <span>Predetermined Max Risk:</span>
            <span>{currencySymbol}{maxRiskAmount.toFixed(0)} ({riskPercent}% of capital)</span>
          </div>

          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex justify-between items-center">
            <div>
              <div className="text-[11px] text-emerald-400 uppercase font-bold">Recommended Quantity</div>
              <div className="text-xl font-extrabold text-emerald-300">{finalQty} Shares</div>
            </div>
            <div className="text-right text-[11px] text-slate-400">
              <div>Required Margin: <strong className="text-white">{currencySymbol}{totalRequiredCapital.toLocaleString()}</strong></div>
              <div>Max Loss if SL hits: <strong className="text-rose-400">{currencySymbol}{potentialLossAtSl.toFixed(0)}</strong></div>
            </div>
          </div>

          <div className="space-y-1 text-[11px] text-slate-400 pt-1">
            <div className="flex justify-between">
              <span>Target 1 Exit (50% qty @ {currencySymbol}{t1.toFixed(0)}):</span>
              <span className="text-emerald-400 font-semibold">+{currencySymbol}{profitAtT1.toFixed(0)}</span>
            </div>
            <div className="flex justify-between">
              <span>Target 2 Exit (30% qty @ {currencySymbol}{t2.toFixed(0)}):</span>
              <span className="text-emerald-400 font-semibold">+{currencySymbol}{profitAtT2.toFixed(0)}</span>
            </div>
          </div>
        </div>

        {/* Institutional Rule Reminder */}
        <div className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-900 border border-slate-800 mb-6 text-xs text-slate-300">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>
            <strong className="text-amber-300">Golden Algo Rule:</strong> Order fill hote hi immediately Stop Loss (
            <span className="text-rose-400 font-mono font-bold">{currencySymbol}{sl.toFixed(2)}</span>) system me place karein. Jab Target 1 hit ho, Stop Loss ko Cost (<span className="text-cyan-400 font-mono font-bold">{currencySymbol}{entry.toFixed(2)}</span>) par trail kar dein.
          </p>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onExecuteTrade(finalQty);
              onClose();
            }}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs rounded-lg shadow-lg shadow-emerald-500/20 transition-all font-mono"
          >
            <CheckCircle2 className="w-4 h-4" />
            Execute {finalQty} Shares with Auto-SL &amp; Targets
          </button>
        </div>
      </div>
    </div>
  );
};
