import React from 'react';
import { Clock, ShieldAlert, Target, Zap, Cpu, CheckCircle2, ChevronRight } from 'lucide-react';

interface WorkshopCurriculumProps {
  onRegisterClick: () => void;
}

export const WorkshopCurriculum: React.FC<WorkshopCurriculumProps> = ({ onRegisterClick }) => {
  const modules = [
    {
      step: '01',
      title: 'When to Invest & Stock Selection Timing',
      timing: '09:45 AM – 11:15 AM Rule',
      icon: Clock,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/10',
      borderColor: 'border-cyan-500/30',
      description: 'Learn the exact institutional liquidity windows. How to filter 500+ stocks down to 2 high-probability breakout setups and avoid the first 15-min retail trap.',
      takeaways: [
        'Why entering at 9:15 AM wipes out 90% of retail traders',
        '15-minute candle body breakout formula with 1.8x volume confirmation',
        'Top 10 Indian equities with the cleanest institutional order blocks',
      ],
    },
    {
      step: '02',
      title: 'Kab Stop Loss Lagana Hai (SL Timing & Mechanics)',
      timing: 'Within 5 Seconds of Entry',
      icon: ShieldAlert,
      color: 'text-rose-400',
      bgColor: 'bg-rose-500/10',
      borderColor: 'border-rose-500/30',
      description: 'Why mental stop-loss is suicide for retail traders. Learn the automated hard-bracket order method that institutional algorithms execute in 0.3 milliseconds.',
      takeaways: [
        'How to place the hard Stop Loss immediately upon order fill',
        '1 ATR buffer below swing low to avoid operator stop-hunts',
        'The Trailing SL Secret: Moving SL to Cost upon Target 1 (Zero-Risk Trade)',
      ],
    },
    {
      step: '03',
      title: 'Profit Booking Strategy (The 50/30/20 Rule)',
      timing: 'Systematic Profit Targets',
      icon: Target,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10',
      borderColor: 'border-emerald-500/30',
      description: 'Never let a green trade turn red. Systematic exit targets engineered to lock profit in stages while letting winners run.',
      takeaways: [
        'Target 1: Book 50% shares at 1:1.8 R:R and lock initial profit',
        'Target 2: Book 30% shares at 1:3.2 R:R into key liquidity zones',
        'Runner 20%: Hold with trailing 20 EMA / Supertrend for multi-day continuation',
      ],
    },
    {
      step: '04',
      title: 'Autopilot Strategy Builder (No-Code)',
      timing: 'Sub-Millisecond Execution',
      icon: Cpu,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/10',
      borderColor: 'border-indigo-500/30',
      description: 'Deploy algorithms using simple visual logic. Turn indicators like VWAP, Supertrend, and EMA Cross into 24/7 automated scanning bots.',
      takeaways: [
        'How to backtest 5 years of historical tick data in 3 seconds',
        'Eliminate emotions: Fear, greed, and revenge trading eradicated',
        '1-click integration with Zerodha, Upstox, AngelOne, or Dhan APIs',
      ],
    },
  ];

  return (
    <section className="py-16 sm:py-24 bg-[#0A0E17] border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono text-xs font-semibold">
            <span>COMPREHENSIVE MASTERCLASS CURRICULUM</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            What You Will Learn in This 2-Hour Live Workshop
          </h2>
          <p className="text-sm text-slate-400 font-mono">
            Direct answers to when to invest, when to exit with profits, and how to protect capital with algorithmic stop losses.
          </p>
        </div>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {modules.map((m) => {
            const Icon = m.icon;
            return (
              <div
                key={m.step}
                className="p-6 sm:p-7 rounded-2xl bg-[#0D121F] border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between space-y-5 shadow-xl group"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2.5 rounded-xl ${m.bgColor} border ${m.borderColor} ${m.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">
                          MODULE {m.step}
                        </span>
                        <h3 className="text-lg font-bold text-white tracking-tight group-hover:text-cyan-300 transition-colors">
                          {m.title}
                        </h3>
                      </div>
                    </div>
                    <span className="text-xs font-mono px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
                      {m.timing}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    {m.description}
                  </p>

                  <div className="space-y-2 pt-2 border-t border-slate-800/80">
                    {m.takeaways.map((point, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-300 font-sans">
                        <CheckCircle2 className={`w-3.5 h-3.5 ${m.color} shrink-0 mt-0.5`} />
                        <span>{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={onRegisterClick}
                    className="text-xs font-mono font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>Register to unlock this module</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
