import React from 'react';
import { Award, ShieldCheck, CheckCircle2, TrendingUp, Users } from 'lucide-react';

interface InstructorSectionProps {
  onRegisterClick: () => void;
}

export const InstructorSection: React.FC<InstructorSectionProps> = ({ onRegisterClick }) => {
  return (
    <section className="py-16 sm:py-24 bg-[#0A0E17] border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-[#0E1528] via-[#0D1220] to-[#090D18] border border-blue-500/20 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Side: Avatar / Badge */}
            <div className="lg:col-span-5 text-center lg:text-left space-y-4">
              <div className="relative inline-block">
                <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-2xl bg-gradient-to-br from-blue-600 via-indigo-600 to-cyan-500 p-1 shadow-2xl mx-auto">
                  <div className="w-full h-full rounded-2xl bg-slate-950 flex flex-col items-center justify-center text-center p-4">
                    <Award className="w-12 h-12 text-cyan-400 mb-1" />
                    <span className="font-extrabold text-white text-base tracking-tight font-mono">KVANTUM<span className="text-cyan-400">X</span></span>
                    <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Quant Research Desk</span>
                  </div>
                </div>

                <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-emerald-500 text-slate-950 px-3 py-1 rounded-full text-[11px] font-mono font-bold whitespace-nowrap shadow-lg">
                  10+ Years Quant Trading
                </div>
              </div>

              <div className="pt-2">
                <h3 className="text-xl font-extrabold text-white">Lead Quantitative Mentor</h3>
                <p className="text-xs text-cyan-400 font-mono">Founder, KvantumX Algorithmic Research</p>
              </div>
            </div>

            {/* Right Side: Credentials & Bio */}
            <div className="lg:col-span-7 space-y-5 text-slate-300">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/25 text-blue-400 font-mono text-xs font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>INSTITUTIONAL GRADE MENTORSHIP</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                "Trading Is Not An Art. It Is A Quantitative Discipline."
              </h2>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
                Over the last 10+ years, our quantitative team has traded across Indian (NSE/BSE), American (NASDAQ/NYSE), and European equity indices. We built algorithms to eradicate human emotional fallacies — fear of missing out, revenge trading, and failing to execute stop-losses.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs pt-2">
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">COMMUNITY</span>
                  <span className="text-base font-bold text-white">25,000+</span>
                  <span className="text-[10px] text-slate-500 block">Traders Mentored</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">SPEED EDGE</span>
                  <span className="text-base font-bold text-cyan-400">0.3 ms</span>
                  <span className="text-[10px] text-slate-500 block">Execution Latency</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">SL DISCIPLINE</span>
                  <span className="text-base font-bold text-emerald-400">100%</span>
                  <span className="text-[10px] text-slate-500 block">Hard System Orders</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
