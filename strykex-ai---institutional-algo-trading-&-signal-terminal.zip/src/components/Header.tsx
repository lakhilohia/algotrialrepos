import React from 'react';
import { ShieldCheck, Activity, Zap, TrendingUp, Sparkles, BookOpen, Layers, MessageCircle, HelpCircle } from 'lucide-react';

interface HeaderProps {
  activeTab: 'workshop' | 'terminal' | 'radar' | 'guide' | 'backtest' | 'copilot';
  setActiveTab: (tab: 'workshop' | 'terminal' | 'radar' | 'guide' | 'backtest' | 'copilot') => void;
  openPositionsCount: number;
  totalPnl: number;
  autopilotActive: boolean;
  setAutopilotActive: React.Dispatch<React.SetStateAction<boolean>>;
  onOpenPositions: () => void;
  onRegisterClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  openPositionsCount,
  totalPnl,
  autopilotActive,
  setAutopilotActive,
  onOpenPositions,
  onRegisterClick,
}) => {
  return (
    <header className="sticky top-0 z-50 flex items-center justify-between gap-6 px-4 sm:px-8 py-3 bg-[#0A0E17]/95 backdrop-blur-md border-b border-slate-800/80">
      {/* Zone 1: Brand Wordmark (Proprietary & Copyright-Safe) */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={() => setActiveTab('workshop')}
          className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-white whitespace-nowrap cursor-pointer text-left"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 via-indigo-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/25">
            <Zap className="w-4 h-4 text-white fill-white" />
          </div>
          <div className="flex flex-col">
            <span className="font-extrabold tracking-tight text-white leading-tight">
              KVANTUM<span className="text-cyan-400">X</span>
            </span>
            <span className="text-[9px] font-mono text-slate-400 tracking-wider uppercase font-semibold">
              QUANTLABS RESEARCH
            </span>
          </div>
        </button>
      </div>

      {/* Zone 2: Navigation Links (Single Line, 4-5 Clean Links) */}
      <nav className="hidden lg:flex items-center gap-1.5 xl:gap-2.5 text-xs font-semibold text-slate-400">
        <button
          onClick={() => setActiveTab('workshop')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'workshop'
              ? 'bg-blue-600/20 text-blue-300 shadow-sm border border-blue-500/30'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-blue-400" />
          AI Workshop
        </button>

        <button
          onClick={() => setActiveTab('terminal')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'terminal'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          Live Algo Terminal
        </button>

        <button
          onClick={() => setActiveTab('radar')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'radar'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
          Signal Radar
        </button>

        <button
          onClick={() => setActiveTab('guide')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'guide'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          Profit &amp; SL Guide
        </button>

        <button
          onClick={() => setActiveTab('backtest')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'backtest'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-indigo-400" />
          Autopilot &amp; Backtest
        </button>

        <button
          onClick={() => setActiveTab('copilot')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'copilot'
              ? 'bg-slate-800/90 text-white shadow-sm border border-slate-700/60'
              : 'hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          Ask AI
        </button>
      </nav>

      {/* Zone 3: 1 Primary Action Area (with WhatsApp & Sign Up buttons as in the screenshot) */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* WhatsApp Icon Button (matching top right of the user's screenshot) */}
        <a
          href="https://wa.me/919876543210?text=Hello%20KvantumX%20Team%2C%20I%20want%20to%20know%20more%20about%20the%20AI%20Algo%20Trading%20Workshop"
          target="_blank"
          rel="noopener noreferrer"
          className="p-2 rounded-xl bg-slate-900 hover:bg-emerald-950/40 border border-slate-700 hover:border-emerald-500/40 text-emerald-400 transition-colors"
          title="WhatsApp Support & Community"
        >
          <MessageCircle className="w-4 h-4 text-emerald-400" />
        </a>

        {/* Primary CTA button: Register Free / Sign Up */}
        <button
          onClick={onRegisterClick}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#0162CC] to-[#3E57DA] hover:from-blue-600 hover:to-indigo-600 text-white font-bold text-xs sm:text-sm font-sans shadow-md shadow-blue-500/20 transition-all cursor-pointer whitespace-nowrap"
        >
          Sign Up Free
        </button>

        {/* Terminal Quick Access */}
        <button
          onClick={onOpenPositions}
          className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-mono whitespace-nowrap transition-colors"
        >
          <span className="text-slate-400">Positions ({openPositionsCount})</span>
          <span className={`font-semibold ${totalPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalPnl >= 0 ? '+' : ''}₹{totalPnl.toFixed(0)}
          </span>
        </button>
      </div>
    </header>
  );
};
