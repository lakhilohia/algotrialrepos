import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, Play, CheckCircle2, TrendingUp, ShieldCheck, Zap, Bot, Activity } from 'lucide-react';

interface LandingHeroProps {
  onRegisterClick: () => void;
  onLaunchTerminal: () => void;
  sessionTime?: string;
}

export const LandingHero: React.FC<LandingHeroProps> = ({
  onRegisterClick,
  onLaunchTerminal,
  sessionTime = 'Wednesday 11th November, 8:00 PM',
}) => {
  // Countdown timer simulation
  const [timeLeft, setTimeLeft] = useState({ hours: 4, minutes: 28, seconds: 45 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative overflow-hidden pt-8 pb-16 md:pt-14 md:pb-24 border-b border-slate-800/60 bg-[#070A11]">
      {/* Background Grid Pattern & Ambient Gradients matching the screenshot */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1E293B15_1px,transparent_1px),linear-gradient(to_bottom,#1E293B15_1px,transparent_1px)] bg-[size:3.5rem_3.5rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_35%,#000_70%,transparent_100%)] pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-blue-600/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-[350px] h-[250px] bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Headline & Value Proposition */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Top pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/25 text-blue-400 font-mono text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>LIVE AI TRADING MASTERCLASS</span>
              <span className="text-slate-500">·</span>
              <span className="text-emerald-400 font-bold">100% FREE PASS</span>
            </div>

            {/* Main Headline exact phrasing from user photo */}
            <h1 className="text-4xl sm:text-6xl xl:text-7xl font-extrabold text-white tracking-tight leading-[1.08]">
              Learn How To <br />
              Trade Using <br />
              <span className="inline-flex items-center gap-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-300 to-indigo-300">
                <span className="text-cyan-400 text-3xl sm:text-5xl">✦</span> AI Powered
              </span> <br />
              <span className="text-white">Algo Trading</span>
            </h1>

            <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto lg:mx-0 leading-relaxed font-sans">
              Stop guessing. Discover institutional quant algorithms that tell you{' '}
              <strong className="text-white">which stock to pick, exact time of entry</strong>, systematic{' '}
              <strong className="text-emerald-400">profit booking targets</strong>, and{' '}
              <strong className="text-rose-400">kab stop-loss lagana hai</strong>.
            </p>

            {/* Countdown Strip */}
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800/90 inline-flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs font-mono">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                Live Session Starts In:
              </div>
              <div className="flex items-center gap-1.5 text-white font-extrabold text-sm">
                <span className="px-2 py-1 rounded bg-slate-800 border border-slate-700">
                  {String(timeLeft.hours).padStart(2, '0')}h
                </span>
                <span>:</span>
                <span className="px-2 py-1 rounded bg-slate-800 border border-slate-700">
                  {String(timeLeft.minutes).padStart(2, '0')}m
                </span>
                <span>:</span>
                <span className="px-2 py-1 rounded bg-slate-800 border border-slate-700 text-cyan-400">
                  {String(timeLeft.seconds).padStart(2, '0')}s
                </span>
              </div>
              <span className="text-slate-400 text-[11px] hidden sm:inline">
                ({sessionTime})
              </span>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-1">
              <button
                onClick={onRegisterClick}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-[#0162CC] via-[#1E40AF] to-[#3E57DA] hover:from-blue-600 hover:to-indigo-600 text-white font-bold text-sm shadow-xl shadow-blue-500/25 hover:shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer font-sans"
              >
                <span>Reserve Free Seat</span>
                <span className="text-xs text-blue-200 line-through opacity-80">₹499</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onLaunchTerminal}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white font-semibold text-xs font-mono transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Activity className="w-4 h-4 text-emerald-400" />
                <span>Launch Live Algo Terminal</span>
              </button>
            </div>

            {/* Quick Proof Badges */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 pt-3 text-xs text-slate-400 font-mono">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>No Coding Required</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Zero Risk Paper Simulator</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Bonuses Worth ₹24,999</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Mockup matching the floating cards in screenshot */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main Preview Box: Nifty 50 Chart Preview */}
              <div className="rounded-2xl bg-gradient-to-b from-[#0E1528] to-[#0A0E1A] border border-blue-500/30 p-5 shadow-2xl relative overflow-hidden">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">NIFTY 50</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">15m</span>
                    <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      ✦ AI scanning
                    </span>
                  </div>
                  <span className="text-slate-400">₹24,327.30 (+1.12%)</span>
                </div>

                {/* Simulated Candlestick Graphic */}
                <div className="py-6 px-2 flex items-end justify-between h-44 gap-1.5">
                  {[45, 52, 48, 65, 72, 68, 85, 92, 88, 110, 125, 120, 140, 155].map((h, i) => {
                    const isGreen = i % 3 !== 0;
                    return (
                      <div key={i} className="flex-1 flex flex-col items-center gap-1">
                        <div
                          className={`w-1 rounded-sm ${isGreen ? 'bg-emerald-400' : 'bg-rose-500'}`}
                          style={{ height: `${h * 0.8}px` }}
                        />
                        <div
                          className={`w-full rounded-sm ${isGreen ? 'bg-emerald-500/80' : 'bg-rose-500/80'}`}
                          style={{ height: `${h * 0.55}px` }}
                        />
                      </div>
                    );
                  })}
                </div>

                {/* Chart Overlay Badge */}
                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <span className="text-slate-300">Target 1 &amp; SL Automated</span>
                  </div>
                  <span className="text-emerald-400 font-bold">1 : 2.85 R:R</span>
                </div>
              </div>

              {/* Floating Card 1: ✦ AI Assistant (exact replica of user's photo) */}
              <div className="absolute -top-6 -left-4 sm:-left-8 bg-white text-slate-900 rounded-2xl p-4 shadow-2xl border border-slate-200 max-w-[270px] space-y-2.5 animate-in slide-in-from-left-4 duration-500">
                <div className="flex items-center gap-2 text-xs font-bold text-blue-600 font-mono">
                  <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">
                    ✦
                  </div>
                  <span>AI Assistant</span>
                </div>

                <div className="bg-slate-100 rounded-xl p-2 text-[11px] font-sans text-slate-700 ml-6 text-right">
                  Where do I start?
                </div>

                <div className="bg-blue-50 text-blue-950 rounded-xl p-2.5 text-[11px] font-sans leading-relaxed">
                  Pick a beginner-friendly strategy, backtest it, then go autopilot.
                </div>
              </div>

              {/* Floating Card 2: ✦ AI SIGNAL (exact replica of user's photo) */}
              <div className="absolute -bottom-8 -right-2 sm:-right-6 bg-slate-900/95 backdrop-blur-md text-white rounded-2xl p-4 shadow-2xl border border-cyan-500/40 max-w-[260px] space-y-2 animate-in slide-in-from-right-4 duration-500">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-cyan-400 font-bold flex items-center gap-1">
                    ✦ AI SIGNAL
                  </span>
                  <span className="text-slate-400 text-[10px]">Just now</span>
                </div>

                <div className="text-sm font-extrabold text-white">
                  Breakout confirmed
                </div>

                <div className="text-[11px] text-slate-400 font-mono">
                  NIFTY 50 · 15m chart
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-800 text-[11px] font-mono">
                  <span className="text-slate-400">Strength:</span>
                  <div className="flex items-center gap-1">
                    <span className="w-3 h-1.5 rounded-sm bg-cyan-400"></span>
                    <span className="w-3 h-1.5 rounded-sm bg-cyan-400"></span>
                    <span className="w-3 h-1.5 rounded-sm bg-cyan-400"></span>
                    <span className="w-3 h-1.5 rounded-sm bg-cyan-400"></span>
                    <span className="w-3 h-1.5 rounded-sm bg-cyan-400"></span>
                    <span className="text-cyan-300 font-bold text-[10px] ml-1">High</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
