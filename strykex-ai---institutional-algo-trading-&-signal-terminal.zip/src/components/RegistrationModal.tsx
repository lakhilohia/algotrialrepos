import React, { useState } from 'react';
import { X, CheckCircle2, Gift, Calendar, Clock, ShieldCheck, ArrowRight, MessageCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface RegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionTime?: string;
}

export const RegistrationModal: React.FC<RegistrationModalProps> = ({
  isOpen,
  onClose,
  sessionTime = 'Wednesday 11th November, 8:00 PM',
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [experience, setExperience] = useState('Beginner');
  const [language, setLanguage] = useState<'Hindi' | 'English'>('Hindi');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !email) return;

    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.5 },
    });

    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0D121F] rounded-2xl border border-slate-700/80 shadow-2xl p-6 sm:p-8 text-slate-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <div>
            {/* Header */}
            <div className="mb-6">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono text-[11px] font-semibold mb-2">
                <Gift className="w-3.5 h-3.5" />
                100% Free · Bonuses Worth ₹24,999 Included
              </div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                Reserve Your Free Masterclass Seat
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Learn institutional algorithmic strategies, exact entry timing &amp; stop-loss rules.
              </p>
            </div>

            {/* Session Time Badge */}
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center gap-3 mb-5 font-mono text-xs">
              <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">LIVE INTERACTIVE SESSION</span>
                <span className="text-white font-bold">{sessionTime}</span>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Sharma"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">WhatsApp Number</label>
                  <input
                    type="tel"
                    required
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Trading Experience</label>
                  <select
                    value={experience}
                    onChange={(e) => setExperience(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-blue-500 focus:outline-none"
                  >
                    <option value="Beginner">Beginner (0-1 yr)</option>
                    <option value="Intermediate">Intermediate (1-3 yrs)</option>
                    <option value="Experienced">Experienced (3+ yrs)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Language</label>
                  <div className="flex bg-slate-900 p-0.5 rounded-xl border border-slate-700">
                    <button
                      type="button"
                      onClick={() => setLanguage('Hindi')}
                      className={`flex-1 py-1.5 text-xs font-mono rounded-lg transition-colors ${
                        language === 'Hindi'
                          ? 'bg-blue-600 text-white font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Hinglish
                    </button>
                    <button
                      type="button"
                      onClick={() => setLanguage('English')}
                      className={`flex-1 py-1.5 text-xs font-mono rounded-lg transition-colors ${
                        language === 'English'
                          ? 'bg-blue-600 text-white font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      English
                    </button>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full mt-2 py-3 bg-gradient-to-r from-[#0162CC] to-[#3E57DA] hover:from-blue-600 hover:to-indigo-600 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer font-sans"
              >
                <span>Complete Free Registration (₹0)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Zero spam · Instant WhatsApp joining link &amp; webinar room access</span>
              </div>
            </form>
          </div>
        ) : (
          /* Confirmation State */
          <div className="text-center py-4 space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-extrabold text-white">
              Seat Confirmed, {name}! 🎉
            </h3>

            <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
              We have sent the private session link and ₹24,999 worth of algo bonuses to{' '}
              <strong className="text-emerald-400">{phone}</strong> and <strong className="text-emerald-400">{email}</strong>.
            </p>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-left font-mono text-xs space-y-2">
              <div className="flex justify-between text-slate-400">
                <span>Date &amp; Time:</span>
                <span className="text-white font-bold">{sessionTime}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Access Status:</span>
                <span className="text-emerald-400 font-bold">FREE TICKET RESERVED</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Language:</span>
                <span className="text-cyan-400">{language}</span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <a
                href="#terminal"
                onClick={(e) => {
                  e.preventDefault();
                  onClose();
                }}
                className="w-full inline-flex items-center justify-center gap-2 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition-all font-mono"
              >
                Launch AI Algo Trading Terminal Now
                <ArrowRight className="w-4 h-4" />
              </a>

              <button
                onClick={onClose}
                className="text-xs text-slate-400 hover:text-white transition-colors"
              >
                Close Window
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
