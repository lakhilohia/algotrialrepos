import React from 'react';
import { Gift, FileCode, Search, Calculator, Users, ArrowRight, CheckCircle2 } from 'lucide-react';

interface BonusesSectionProps {
  onRegisterClick: () => void;
}

export const BonusesSection: React.FC<BonusesSectionProps> = ({ onRegisterClick }) => {
  const bonuses = [
    {
      title: 'Institutional Algo Strategy Source Code & Rules Blueprint',
      val: '₹9,999',
      desc: 'Plug-and-play Python & Pine Script code for the 15-Minute Breakout and VWAP Absorption setup. Ready to deploy on TradingView or brokers.',
      icon: FileCode,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/10',
    },
    {
      title: 'Real-time 15m Breakout & Order Block Scanner Access',
      val: '₹7,999',
      desc: 'Exclusive access to our institutional radar that tracks top 50 Nifty & BankNifty momentum stocks with high delivery percentage.',
      icon: Search,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/10',
    },
    {
      title: 'Automated Stop-Loss & Position Sizing Calculator',
      val: '₹4,999',
      desc: 'Custom Excel & Web tool that instantly calculates exact share quantities based on your account size and 1% max risk rule.',
      icon: Calculator,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10',
    },
    {
      title: 'Private Quant Traders WhatsApp & Discord VIP Alpha Group',
      val: '₹2,000',
      desc: 'Join 10,000+ active algorithmic traders. Daily pre-market levels, morning breakout alerts, and live trading Q&A.',
      icon: Users,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10',
    },
  ];

  return (
    <section className="py-16 sm:py-24 bg-[#070A11] border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono text-xs font-semibold">
            <Gift className="w-3.5 h-3.5" />
            <span>FREE UPON ATTENDANCE</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Unlock Webinar Bonuses Worth <span className="text-emerald-400">₹24,999</span>
          </h2>
          <p className="text-sm text-slate-400 font-mono">
            Register today and receive instant access to all 4 quantitative tools and resources immediately after the live workshop.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {bonuses.map((b, i) => {
            const Icon = b.icon;
            return (
              <div
                key={i}
                className="p-6 rounded-2xl bg-[#0D121F] border border-slate-800/90 hover:border-slate-700 flex flex-col justify-between space-y-4 shadow-xl group transition-all"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className={`p-2.5 rounded-xl ${b.bgColor} ${b.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono font-extrabold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
                      VALUE: {b.val}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white tracking-tight group-hover:text-cyan-300 transition-colors">
                    {b.title}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed font-sans">
                    {b.desc}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center gap-1.5 text-[11px] font-mono text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>100% Free with Workshop Registration</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={onRegisterClick}
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-[#0162CC] to-[#3E57DA] hover:from-blue-600 hover:to-indigo-600 text-white font-bold text-sm rounded-xl shadow-xl shadow-blue-500/25 hover:scale-[1.02] active:scale-[0.98] transition-all font-sans cursor-pointer"
          >
            <span>Claim All 4 Bonuses Free (Register Now)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
