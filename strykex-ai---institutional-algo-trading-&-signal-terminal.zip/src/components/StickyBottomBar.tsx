import React from 'react';
import { ArrowRight, Sparkles, Clock } from 'lucide-react';

interface StickyBottomBarProps {
  onRegisterClick: () => void;
  sessionTime?: string;
}

export const StickyBottomBar: React.FC<StickyBottomBarProps> = ({
  onRegisterClick,
  sessionTime = 'Wednesday 11th November, 8:00 PM',
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-gradient-to-r from-[#0162CC] via-[#1E40AF] to-[#3E57DA] shadow-[0_-5px_25px_rgba(1,98,204,0.35)] border-t border-blue-400/30 py-2.5 px-4 sm:px-8">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Left Side: Pricing Badge */}
        <div className="flex items-center gap-3 text-white font-mono">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold tracking-tight">Free</span>
            <span className="text-base sm:text-lg text-blue-200 line-through opacity-80 decoration-white decoration-1 font-semibold">
              ₹499
            </span>
          </div>
          <span className="hidden md:inline-block text-xs font-sans text-blue-100 bg-white/10 px-2.5 py-1 rounded-full border border-white/20">
            Limited Free Seats · 100% Practical AI Workshop
          </span>
        </div>

        {/* Right Side: Primary Registration CTA (matching the screenshot) */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={onRegisterClick}
            className="w-full sm:w-auto px-6 py-2.5 sm:py-3 bg-white hover:bg-slate-50 text-[#0162CC] font-bold text-sm sm:text-base rounded-xl sm:rounded-2xl shadow-xl hover:shadow-2xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer font-sans"
          >
            <span>Register Now</span>
            <span className="text-xs sm:text-sm font-medium text-slate-700">
              ({sessionTime})
            </span>
            <ArrowRight className="w-4 h-4 text-[#0162CC]" />
          </button>
        </div>
      </div>
    </div>
  );
};
