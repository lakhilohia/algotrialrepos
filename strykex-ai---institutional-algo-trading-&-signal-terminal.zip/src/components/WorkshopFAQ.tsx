import React, { useState } from 'react';
import { ChevronDown, HelpCircle, ArrowRight } from 'lucide-react';

interface WorkshopFAQProps {
  onRegisterClick: () => void;
}

export const WorkshopFAQ: React.FC<WorkshopFAQProps> = ({ onRegisterClick }) => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Do I need Python, C++, or coding skills to use Algo Trading?',
      a: 'Absolutely not. Our algorithmic software uses visual parameters, pre-built quant logic, and English prompts. You simply set your risk percentage (1%), pick the stock, and the algorithm calculates the exact quantity, stop-loss, and profit targets automatically.',
    },
    {
      q: 'How does the algorithm guide me when to invest and in which stock?',
      a: 'The Live Signal Radar continuously tracks the entire Nifty 50 and BankNifty basket. Between 09:45 AM and 11:15 AM, when institutional breakout criteria are confirmed (15m candle close + 1.8x volume spike), the algorithm prints the exact Entry Zone and time trigger.',
    },
    {
      q: 'Kab aur kaise Stop Loss lagana chahiye?',
      a: 'The golden institutional rule is: The Hard Stop Loss must be placed on the broker terminal WITHIN 5 SECONDS of your entry order filling. We never use mental stop losses. Furthermore, as soon as Target 1 is achieved, the algorithm instructs you to trail the Stop Loss to your Entry Cost, making the trade 100% risk-free.',
    },
    {
      q: 'How does partial profit booking work?',
      a: 'We teach the institutional 50/30/20 framework: Target 1 (1:1.8 R:R) books 50% shares to secure realized green P&L. Target 2 books 30% shares. The remaining 20% runner is held with a trailing 20 EMA / Supertrend stop to catch major multi-day trend continuations.',
    },
    {
      q: 'Can working professionals use this without staring at charts all day?',
      a: 'Yes! That is the primary advantage of quantitative algo trading. You can pre-schedule bracket orders before market opens or enable the Autopilot engine which handles exits and trailing stop losses automatically while you focus on your job.',
    },
    {
      q: 'What if I miss the live workshop time?',
      a: 'All registered attendees receive full lifetime access to the session HD replay, along with all 4 downloadable bonus tools and strategy source code.',
    },
  ];

  return (
    <section className="py-16 sm:py-24 bg-[#070A11] border-b border-slate-800/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono text-xs font-semibold">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>FREQUENTLY ASKED QUESTIONS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Got Questions? We Have Answers.
          </h2>
          <p className="text-sm text-slate-400 font-mono">
            Everything you need to know about our quantitative masterclass and trading software.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl bg-[#0D121F] border border-slate-800 overflow-hidden transition-all"
              >
                <button
                  onClick={() => setOpenIdx(isOpen ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 text-sm sm:text-base font-bold text-white hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-cyan-400' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans border-t border-slate-800/60 animate-in fade-in duration-200">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={onRegisterClick}
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-[#0162CC] to-[#3E57DA] hover:from-blue-600 hover:to-indigo-600 text-white font-bold text-sm rounded-xl shadow-xl shadow-blue-500/25 hover:scale-[1.02] active:scale-[0.98] transition-all font-sans cursor-pointer"
          >
            <span>Register for Free Masterclass Today</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
