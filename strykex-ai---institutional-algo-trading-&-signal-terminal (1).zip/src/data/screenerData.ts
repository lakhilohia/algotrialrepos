import { ScreenerDocument, ScreenerRatios } from '../types/trading';

export const screenerRatiosReliance: ScreenerRatios = {
  marketCap: 1758400, // ₹17,58,400 Cr
  currentPrice: 1298.50, // Around ₹1,300 post 1:1 bonus
  high52: 1328.00,
  low52: 1215.00,
  pe: 24.8,
  bookValue: 718.50,
  dividendYield: 0.39,
  roce: 10.6,
  roe: 9.8,
  faceValue: 10,
  promoterHolding: 50.3,
  fiiHolding: 21.8,
  diiHolding: 17.1,
  publicHolding: 10.8,
  salesGrowth3Yr: 18.2,
  profitGrowth3Yr: 14.5,
};

export const screenerFeedDocuments: ScreenerDocument[] = [
  {
    id: 'scr-0',
    companyName: 'Reliance Industries Ltd',
    docType: 'Transcript',
    date: 'Concall - 11 Nov 2026',
    highlight: 'reliance',
    snippet:
      'Q2/Q3 Institutional Earnings: Jio ARPU scaled to ₹195 with 5G user base crossing 135M. Reliance Retail opened 420 new stores with 18% YoY footprint growth. Oil-to-Chemicals (O2C) margin stabilized. Jamnagar New Energy solar gigafactory phase 1 on-stream.',
    relatedStockSymbol: 'RELIANCE',
  },
  {
    id: 'scr-1',
    companyName: 'Texmaco Rail & Engineering Ltd',
    docType: 'Presentation',
    date: 'Concall - 11 Nov 2026',
    highlight: 'reliance',
    snippet:
      'plant commissioned at Raipur under group captive scheme, reducing reliance on conventional energy • Belgharia foundry furnace converted from LDO to cleaner energy sources.',
    relatedStockSymbol: 'TEXMACO',
  },
  {
    id: 'scr-2',
    companyName: 'MSTC Ltd',
    docType: 'Key points',
    date: '10 Nov 2026',
    highlight: 'Reliance',
    snippet:
      'Its private clients include Reliance, Vedanta, Tata Group, JSW, L&T, Indus Towers and AM/NS. b) E-sales of natural resources: Company sells coal, petcoke and critical industrial minerals to Reliance petchem units.',
    relatedStockSymbol: 'MSTC',
  },
  {
    id: 'scr-3',
    companyName: 'Platinum Industries Ltd',
    docType: 'Transcript',
    date: 'Concall - 10 Nov 2026',
    highlight: 'Reliance',
    snippet:
      'industry, PVC pipe industry. So, this is also the records that we have. We keep talking to companies like Reliance. So, they were also like, 18% to 22% volume expansion expected across polymer additives.',
    relatedStockSymbol: 'PLATIND',
  },
  {
    id: 'scr-4',
    companyName: 'V-Mart Retail Ltd',
    docType: 'Transcript',
    date: 'Concall - 10 Nov 2026',
    highlight: 'Reliance',
    snippet:
      'of Reliance Trends or Max, their average selling price is much higher than what we do. So that is how we are able to clearly have a very clear competitive niche in Tier-2/Tier-3 towns.',
    relatedStockSymbol: 'VMART',
  },
  {
    id: 'scr-5',
    companyName: 'Reliance Communications Ltd',
    docType: 'Announcement',
    date: 'Announcement - 10 Nov 2026',
    highlight: 'Reliance',
    snippet:
      'Disclosure Under Regulation 30 - Communications Issued By The Department Of Telecommunications, Ministry Of Communications, Government Of India, Seeking Partial Encashment Of Bank Guarantees Of Reliance Communications Limited And Subsidiary.',
    relatedStockSymbol: 'RCOM',
  },
  {
    id: 'scr-6',
    companyName: 'AVP Infracon Ltd',
    docType: 'Transcript',
    date: 'Concall - 09 Nov 2026',
    highlight: 'Reliance',
    snippet:
      'balance of Rs.275, almost Rs.200 Crores is from, 225 will be from NHAI. So, balance will be from this private thing, we have private commercial work order from Reliance Jamnagar expansion.',
    relatedStockSymbol: 'AVPINFRA',
  },
  {
    id: 'scr-7',
    companyName: 'Aurobindo Pharma Ltd',
    docType: 'Transcript',
    date: 'Concall - 11 Nov 2026',
    highlight: 'reliance',
    snippet:
      'growth and reduce reliance on any single product. Strengthening and monetizing our US business: In the US, Lannett acquisition has broadened our respiratory injectables and biosimilar portfolio.',
    relatedStockSymbol: 'AUROPHARMA',
  },
  {
    id: 'scr-8',
    companyName: 'Sandhar Technologies Limited',
    docType: 'Presentation',
    date: 'Concall - 11 Nov 2026',
    highlight: 'reliance',
    snippet:
      'no reliance shall be placed on, the truth, accuracy, completeness, fairness and reasonableness of the contents of this Presentation. EV smart locking & die casting product line update.',
    relatedStockSymbol: 'SANDHAR',
  },
  {
    id: 'scr-9',
    companyName: 'Talbros Automotive Components Ltd',
    docType: 'Presentation',
    date: 'Concall - 11 Nov 2026',
    highlight: 'reliance',
    snippet:
      'express or implied, is made as to, and no reliance should be placed on, the fairness, accuracy, completeness or correctness of the information. Gasket and suspension order book at ₹1,850 Cr.',
    relatedStockSymbol: 'TALBROAUTO',
  },
  {
    id: 'scr-10',
    companyName: 'RNFI Services Ltd',
    docType: 'Presentation',
    date: 'Concall - 11 Nov 2026',
    highlight: 'reliance',
    snippet:
      'reliance should not be placed on them. This Presentation may not be exhaustive and highlights financial inclusion banking services expansion in northern corridors.',
    relatedStockSymbol: 'RNFI',
  },
  {
    id: 'scr-11',
    companyName: 'Midwest Ltd',
    docType: 'Presentation',
    date: 'Concall - 11 Nov 2026',
    highlight: 'reliance',
    snippet:
      'significantly, supported by a stringent credit policy and favorable customer payment terms that ensured healthy cash flow and reduced reliance on external working capital debt.',
    relatedStockSymbol: 'MIDWEST',
  },
  {
    id: 'scr-12',
    companyName: 'Macpower CNC Machines Ltd',
    docType: 'Announcement',
    date: 'Announcement - 09 Nov 2026',
    highlight: 'reliance',
    snippet:
      'Disclosure under SEBI Takeover Regulations: Report to stock exchange in respect of acquisition made in reliance upon exemption provided under Regulation 10 of SEBI (SAST) Regulations, 2011.',
    relatedStockSymbol: 'MACPOWER',
  },
  {
    id: 'scr-13',
    companyName: 'Fratelli Vineyards Ltd',
    docType: 'Presentation',
    date: 'Concall - 10 Nov 2026',
    highlight: 'reliance',
    snippet:
      'reliance on these forward-looking statements. An Overview of India’s Leading Winemaker Strategic Priorities Q2/Q3 distribution expansion across premium retail chains.',
    relatedStockSymbol: 'FRATELLI',
  },
];
