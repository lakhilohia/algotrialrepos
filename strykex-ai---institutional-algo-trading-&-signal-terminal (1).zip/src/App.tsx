import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { LandingHero } from './components/LandingHero';
import { WorkshopCurriculum } from './components/WorkshopCurriculum';
import { BonusesSection } from './components/BonusesSection';
import { InstructorSection } from './components/InstructorSection';
import { WorkshopFAQ } from './components/WorkshopFAQ';
import { StickyBottomBar } from './components/StickyBottomBar';
import { RegistrationModal } from './components/RegistrationModal';
import { TradingTerminal } from './components/TradingTerminal';
import { SignalRadar } from './components/SignalRadar';
import { ProfitAndStopLossGuide } from './components/ProfitAndStopLossGuide';
import { BacktestEngine } from './components/BacktestEngine';
import { AICopilot } from './components/AICopilot';
import { LivePositionTracker } from './components/LivePositionTracker';
import { ScreenerFeed } from './components/ScreenerFeed';
import { initialStocks } from './data/mockStocks';
import { StockItem, Position } from './types/trading';
import confetti from 'canvas-confetti';
import { Zap } from 'lucide-react';

export default function App() {
  const [stocks, setStocks] = useState<StockItem[]>(initialStocks);
  const [selectedStock, setSelectedStock] = useState<StockItem>(initialStocks[0]);
  const [activeTab, setActiveTab] = useState<'workshop' | 'terminal' | 'radar' | 'screener' | 'guide' | 'backtest' | 'copilot'>('workshop');
  const [autopilotActive, setAutopilotActive] = useState<boolean>(true);
  const [isPositionsModalOpen, setIsPositionsModalOpen] = useState<boolean>(false);
  const [isRegistrationModalOpen, setIsRegistrationModalOpen] = useState<boolean>(false);
  const [alertNotification, setAlertNotification] = useState<string | null>(null);

  const sessionTime = 'Wednesday 11th November, 8:00 PM';

  // Sample pre-seeded position on Reliance (calibrated to post-bonus ~₹1,300 range)
  const [positions, setPositions] = useState<Position[]>([
    {
      id: 'pos-1',
      symbol: 'RELIANCE',
      type: 'BUY',
      entryPrice: 1292.00,
      entryTime: '09:48 AM',
      quantity: 80,
      currentPrice: 1298.50,
      stopLoss: 1274.00,
      target1: 1335.00,
      target2: 1372.00,
      target3: 1410.00,
      target1Hit: false,
      target2Hit: false,
      trailingSlActive: false,
      unrealizedPnl: (1298.50 - 1292.00) * 80,
      unrealizedPnlPercent: ((1298.50 - 1292.00) / 1292.00) * 100,
      status: 'OPEN',
      log: [
        '09:48:02 AM: Algo Buy Order Executed @ ₹1,292.00 (80 shares) in post-bonus ₹1,300 zone',
        '09:48:05 AM: Hard Stop-Loss Order Placed @ ₹1,274.00 (Max predetermined risk: ₹1,440)',
      ],
    },
  ]);

  // Micro-tick market simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setStocks((prevStocks) =>
        prevStocks.map((stock) => {
          const tickDelta = (Math.random() - 0.48) * (stock.price * 0.0006);
          const newPrice = Number((stock.price + tickDelta).toFixed(2));
          const newChange = Number((newPrice - stock.prevClose).toFixed(2));
          const newChangePercent = Number(((newChange / stock.prevClose) * 100).toFixed(2));

          const updatedCandles = [...stock.candles];
          if (updatedCandles.length > 0) {
            const lastCandle = { ...updatedCandles[updatedCandles.length - 1] };
            lastCandle.close = newPrice;
            lastCandle.high = Math.max(lastCandle.high, newPrice);
            lastCandle.low = Math.min(lastCandle.low, newPrice);
            updatedCandles[updatedCandles.length - 1] = lastCandle;
          }

          return {
            ...stock,
            price: newPrice,
            change: newChange,
            changePercent: newChangePercent,
            candles: updatedCandles,
          };
        })
      );
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  // Update position unrealized P&L
  useEffect(() => {
    setPositions((prevPositions) =>
      prevPositions.map((pos) => {
        const liveStock = stocks.find((s) => s.symbol === pos.symbol);
        if (!liveStock || pos.status === 'CLOSED_PROFIT' || pos.status === 'CLOSED_SL') return pos;

        const pnl = (liveStock.price - pos.entryPrice) * pos.quantity;
        const pnlPercent = ((liveStock.price - pos.entryPrice) / pos.entryPrice) * 100;

        if (autopilotActive && !pos.target1Hit && liveStock.price >= pos.target1) {
          triggerTargetHit(pos.id, 1);
        }

        if (liveStock.price <= pos.stopLoss) {
          triggerSlHit(pos.id);
        }

        return {
          ...pos,
          currentPrice: liveStock.price,
          unrealizedPnl: pnl,
          unrealizedPnlPercent: pnlPercent,
        };
      })
    );
  }, [stocks, autopilotActive]);

  useEffect(() => {
    const updated = stocks.find((s) => s.symbol === selectedStock.symbol);
    if (updated) {
      setSelectedStock(updated);
    }
  }, [stocks]);

  const handleExecuteTrade = (stock: StockItem, qty: number) => {
    const newPos: Position = {
      id: `pos-${Date.now()}`,
      symbol: stock.symbol,
      type: 'BUY',
      entryPrice: stock.price,
      entryTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      quantity: qty,
      currentPrice: stock.price,
      stopLoss: stock.algoSetup.stopLoss.price,
      target1: stock.algoSetup.target1.price,
      target2: stock.algoSetup.target2.price,
      target3: stock.algoSetup.target3Runner.price,
      target1Hit: false,
      target2Hit: false,
      trailingSlActive: false,
      unrealizedPnl: 0,
      unrealizedPnlPercent: 0,
      status: 'OPEN',
      log: [
        `${new Date().toLocaleTimeString()}: Algo Buy Order filled @ ₹${stock.price.toFixed(2)} (${qty} shares)`,
        `${new Date().toLocaleTimeString()}: Hard Stop-Loss placed @ ₹${stock.algoSetup.stopLoss.price.toFixed(2)}`,
      ],
    };

    setPositions((prev) => [newPos, ...prev]);
    setAlertNotification(`Order Placed: ${qty} shares of ${stock.symbol} @ ₹${stock.price.toFixed(2)} with Hard SL @ ₹${stock.algoSetup.stopLoss.price}`);
    setTimeout(() => setAlertNotification(null), 5000);
  };

  const triggerTargetHit = (id: string, targetNum: 1 | 2) => {
    setPositions((prev) =>
      prev.map((pos) => {
        if (pos.id !== id) return pos;

        if (targetNum === 1) {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
          });

          const bookedProfit = (pos.target1 - pos.entryPrice) * (pos.quantity * 0.5);
          const newLog = [
            ...pos.log,
            `Target 1 Hit! Booked 50% profit (+₹${bookedProfit.toFixed(2)})`,
            `Stop-Loss Trailed to Cost (₹${pos.entryPrice.toFixed(2)}). Trade is now ZERO RISK!`,
          ];

          setAlertNotification(`🎯 Target 1 HIT on ${pos.symbol}! Booked 50% profit. Stop Loss trailed to ₹${pos.entryPrice} (Risk-Free).`);
          setTimeout(() => setAlertNotification(null), 6000);

          return {
            ...pos,
            target1Hit: true,
            trailingSlActive: true,
            stopLoss: pos.entryPrice,
            status: 'CLOSED_PARTIAL',
            log: newLog,
          };
        } else {
          confetti({
            particleCount: 120,
            spread: 90,
            origin: { y: 0.5 },
          });

          const bookedProfit = (pos.target2 - pos.entryPrice) * (pos.quantity * 0.3);
          const newLog = [
            ...pos.log,
            `Target 2 Hit! Booked 30% profit (+₹${bookedProfit.toFixed(2)})`,
            `Stop-Loss Trailed to Target 1 (₹${pos.target1.toFixed(2)}) for remaining 20% runner.`,
          ];

          setAlertNotification(`🚀 Target 2 HIT on ${pos.symbol}! Booked 30% profit. Holding runner 20% with trailing stop.`);
          setTimeout(() => setAlertNotification(null), 6000);

          return {
            ...pos,
            target2Hit: true,
            stopLoss: pos.target1,
            log: newLog,
          };
        }
      })
    );
  };

  const triggerSlHit = (id: string) => {
    setPositions((prev) =>
      prev.map((pos) => {
        if (pos.id !== id) return pos;

        const realizedPnl = (pos.stopLoss - pos.entryPrice) * pos.quantity;
        const newLog = [
          ...pos.log,
          `Stop-Loss Hit @ ₹${pos.stopLoss.toFixed(2)}. Capital protected at predetermined risk.`,
        ];

        setAlertNotification(`🛑 Stop Loss Triggered on ${pos.symbol} @ ₹${pos.stopLoss.toFixed(2)}. Trade closed cleanly.`);
        setTimeout(() => setAlertNotification(null), 5000);

        return {
          ...pos,
          status: 'CLOSED_SL',
          exitPrice: pos.stopLoss,
          exitTime: new Date().toLocaleTimeString(),
          realizedPnl,
          log: newLog,
        };
      })
    );
  };

  const handleClosePosition = (id: string) => {
    setPositions((prev) =>
      prev.map((pos) => {
        if (pos.id !== id) return pos;
        return {
          ...pos,
          status: 'CLOSED_PROFIT',
          exitPrice: pos.currentPrice,
          exitTime: new Date().toLocaleTimeString(),
          realizedPnl: pos.unrealizedPnl,
          log: [...pos.log, `Manual Exit @ ₹${pos.currentPrice.toFixed(2)}`],
        };
      })
    );
  };

  const openPositions = positions.filter((p) => p.status === 'OPEN' || p.status === 'CLOSED_PARTIAL');
  const totalPnl = openPositions.reduce((acc, p) => acc + p.unrealizedPnl, 0);

  return (
    <div className="min-h-screen bg-[#070A11] text-[#E2E8F0] font-sans antialiased flex flex-col pb-20">
      {/* Top Navigation Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openPositionsCount={openPositions.length}
        totalPnl={totalPnl}
        autopilotActive={autopilotActive}
        setAutopilotActive={setAutopilotActive}
        onOpenPositions={() => setIsPositionsModalOpen(true)}
        onRegisterClick={() => setIsRegistrationModalOpen(true)}
      />

      {/* Floating System Notification Toast */}
      {alertNotification && (
        <div className="fixed bottom-24 right-6 z-50 p-4 rounded-xl bg-slate-900 border border-emerald-500/50 shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-bottom-3 max-w-md">
          <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0">
            <Zap className="w-5 h-5" />
          </div>
          <div className="text-xs font-mono text-slate-200">
            {alertNotification}
          </div>
        </div>
      )}

      {/* WORKSHOP LANDING VIEW (Matches user's screenshot & stockwiz landing page) */}
      {activeTab === 'workshop' && (
        <main className="flex-1">
          <LandingHero
            onRegisterClick={() => setIsRegistrationModalOpen(true)}
            onLaunchTerminal={() => setActiveTab('terminal')}
            sessionTime={sessionTime}
          />
          <WorkshopCurriculum onRegisterClick={() => setIsRegistrationModalOpen(true)} />
          <BonusesSection onRegisterClick={() => setIsRegistrationModalOpen(true)} />
          <InstructorSection onRegisterClick={() => setIsRegistrationModalOpen(true)} />
          <WorkshopFAQ onRegisterClick={() => setIsRegistrationModalOpen(true)} />

          {/* Sticky Bottom Bar from Screenshot */}
          <StickyBottomBar
            onRegisterClick={() => setIsRegistrationModalOpen(true)}
            sessionTime={sessionTime}
          />
        </main>
      )}

      {/* LIVE ALGO SOFTWARE & TERMINAL VIEWS */}
      {activeTab !== 'workshop' && (
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-7xl mx-auto w-full">
          {activeTab === 'terminal' && (
            <TradingTerminal
              stocks={stocks}
              selectedStock={selectedStock}
              setSelectedStock={setSelectedStock}
              onExecuteTrade={handleExecuteTrade}
            />
          )}

          {activeTab === 'radar' && (
            <SignalRadar
              stocks={stocks}
              onSelectStock={(stock) => {
                setSelectedStock(stock);
                setActiveTab('terminal');
              }}
            />
          )}

          {activeTab === 'screener' && (
            <ScreenerFeed
              relianceStock={stocks.find((s) => s.symbol === 'RELIANCE') || stocks[0]}
              onTradeStock={(stk) => {
                setSelectedStock(stk);
                setActiveTab('terminal');
              }}
            />
          )}

          {activeTab === 'guide' && <ProfitAndStopLossGuide />}

          {activeTab === 'backtest' && <BacktestEngine />}

          {activeTab === 'copilot' && <AICopilot selectedStock={selectedStock} />}
        </main>
      )}

      {/* Registration Modal */}
      <RegistrationModal
        isOpen={isRegistrationModalOpen}
        onClose={() => setIsRegistrationModalOpen(false)}
        sessionTime={sessionTime}
      />

      {/* Positions Drawer / Modal */}
      <LivePositionTracker
        isOpen={isPositionsModalOpen}
        onClose={() => setIsPositionsModalOpen(false)}
        positions={positions}
        onClosePosition={handleClosePosition}
        onSimulateTargetHit={triggerTargetHit}
        onSimulateSlHit={triggerSlHit}
      />
    </div>
  );
}
