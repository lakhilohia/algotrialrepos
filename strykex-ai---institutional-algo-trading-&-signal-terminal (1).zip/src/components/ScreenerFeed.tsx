import React, { useState } from 'react';
import {
  Search,
  Filter,
  FileText,
  TrendingUp,
  ExternalLink,
  Building2,
  Calendar,
  Layers,
  ArrowUpRight,
  RefreshCw,
  SlidersHorizontal,
  CheckCircle2,
} from 'lucide-react';
import { screenerRatiosReliance, screenerFeedDocuments } from '../data/screenerData';
import { StockItem } from '../types/trading';

interface ScreenerFeedProps {
  relianceStock: StockItem;
  onTradeStock: (stock: StockItem) => void;
}

export const ScreenerFeed: React.FC<ScreenerFeedProps> = ({ relianceStock, onTradeStock }) => {
  const [searchTerm, setSearchTerm] = useState('reliance');
  const [selectedDocType, setSelectedDocType] = useState<string>('All');
  const [matchType, setMatchType] = useState<'All words' | 'Exact phrase' | 'Any of the word'>('All words');

  // Filter documents
  const filteredDocs = screenerFeedDocuments.filter((doc) => {
    const matchesDocType =
      selectedDocType === 'All' ||
      (selectedDocType === 'Announcements' && doc.docType === 'Announcement') ||
      (selectedDocType === 'Concalls' && (doc.docType === 'Concall' || doc.docType === 'Transcript')) ||
      (selectedDocType === 'Presentations' && doc.docType === 'Presentation') ||
      (selectedDocType === 'Key points' && doc.docType === 'Key points');

    const matchesQuery =
      searchTerm.trim() === '' ||
      doc.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.snippet.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesDocType && matchesQuery;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Screener Navigation Header */}
      <div className="p-5 rounded-2xl bg-[#0D121F] border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Search className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-extrabold text-white tracking-tight">
                  Screener.in Real-Time Database &amp; Concall Intelligence
                </h1>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold uppercase">
                  LIVE TICK SYNC
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Replicating full-text search across 30,726+ filings, concalls, and corporate disclosures
              </p>
            </div>
          </div>

          {/* Reliance Live Fluctuation Ticker Badge */}
          <div className="p-3 rounded-xl bg-slate-900 border border-blue-500/40 flex items-center gap-4 font-mono text-xs shadow-lg">
            <div>
              <span className="text-slate-400 text-[10px] block">RELIANCE (NSE) · Post-Bonus</span>
              <div className="text-base font-extrabold text-white flex items-center gap-1.5">
                <span>₹{relianceStock.price.toFixed(2)}</span>
                <span className={`text-xs ${relianceStock.change >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {relianceStock.change >= 0 ? '+' : ''}{relianceStock.change.toFixed(2)} ({relianceStock.changePercent}%)
                </span>
              </div>
            </div>

            <button
              onClick={() => onTradeStock(relianceStock)}
              className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1 font-mono transition-colors"
            >
              <span>Trade in Terminal</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Screener Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search for a company, concall transcript or filing (e.g. reliance, jio, expansion)..."
            className="w-full pl-10 pr-4 py-3 bg-slate-900/90 border border-slate-700 rounded-xl text-xs sm:text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 shadow-inner"
          />
        </div>
      </div>

      {/* Reliance Industries Key Financial Ratios (Screener.in format) */}
      <div className="p-5 rounded-2xl bg-[#0C101A] border border-slate-800 shadow-xl space-y-3 font-mono">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-bold text-white">
              Reliance Industries Ltd. — Key Ratios (Post-Bonus ₹1,300 Zone)
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            BSE / NSE Delayed by 5-15 mins · Real-Time Micro Ticks Active
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">Market Cap</span>
            <span className="text-sm font-bold text-white">₹{screenerRatiosReliance.marketCap.toLocaleString()} Cr</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">Current Price</span>
            <span className="text-sm font-bold text-emerald-400">₹{relianceStock.price.toFixed(2)}</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">High / Low (52w)</span>
            <span className="text-sm font-bold text-white">₹{screenerRatiosReliance.high52} / ₹{screenerRatiosReliance.low52}</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">Stock P/E</span>
            <span className="text-sm font-bold text-white">{screenerRatiosReliance.pe}</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">Book Value</span>
            <span className="text-sm font-bold text-white">₹{screenerRatiosReliance.bookValue}</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">ROCE / ROE</span>
            <span className="text-sm font-bold text-cyan-300">{screenerRatiosReliance.roce}% / {screenerRatiosReliance.roe}%</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800/60 text-[11px] text-slate-400">
          <div>
            Shareholding: <strong className="text-slate-200">Promoter {screenerRatiosReliance.promoterHolding}%</strong> · <strong className="text-slate-200">FII {screenerRatiosReliance.fiiHolding}%</strong> · <strong className="text-slate-200">DII {screenerRatiosReliance.diiHolding}%</strong> · <strong className="text-slate-200">Public {screenerRatiosReliance.publicHolding}%</strong>
          </div>
          <div>
            3Y Sales Growth: <strong className="text-emerald-400">+{screenerRatiosReliance.salesGrowth3Yr}%</strong> · 3Y Profit Growth: <strong className="text-emerald-400">+{screenerRatiosReliance.profitGrowth3Yr}%</strong>
          </div>
        </div>
      </div>

      {/* Main Screener Feed Content & Sidebar Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: Screener Documents Feed */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 pb-1">
            <span>
              Showing <strong className="text-white">{filteredDocs.length}</strong> results (from 30,726 indexed items)
            </span>
            <span>Query: <strong className="text-cyan-400">"{searchTerm}"</strong></span>
          </div>

          <div className="space-y-3">
            {filteredDocs.map((doc) => (
              <div
                key={doc.id}
                className="p-5 rounded-2xl bg-[#0D121F] border border-slate-800 hover:border-slate-700 transition-all space-y-2 shadow-md group"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm tracking-tight group-hover:text-cyan-300 transition-colors">
                      {doc.companyName}
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        doc.docType === 'Transcript'
                          ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                          : doc.docType === 'Presentation'
                          ? 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
                          : doc.docType === 'Announcement'
                          ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                      }`}
                    >
                      {doc.docType}
                    </span>
                  </div>

                  <span className="text-[11px] font-mono text-slate-500 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {doc.date}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  {doc.snippet.split(new RegExp(`(${doc.highlight})`, 'gi')).map((chunk, i) =>
                    chunk.toLowerCase() === doc.highlight.toLowerCase() ? (
                      <mark key={i} className="bg-yellow-400/20 text-yellow-300 font-semibold px-1 py-0.5 rounded">
                        {chunk}
                      </mark>
                    ) : (
                      chunk
                    )
                  )}
                </p>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
                  <span className="text-slate-500">Source: BSE/NSE Corporate Announcement Feed</span>
                  {doc.relatedStockSymbol === 'RELIANCE' && (
                    <button
                      onClick={() => onTradeStock(relianceStock)}
                      className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1"
                    >
                      View Reliance Algo Setup (₹1,300 Zone)
                      <ArrowUpRight className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Screener Filters Sidebar (matching Screener.in) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-5 rounded-2xl bg-[#0D121F] border border-slate-800 space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3 text-xs font-mono text-white font-bold uppercase">
              <Filter className="w-4 h-4 text-blue-400" />
              <span>Filter By Documents</span>
            </div>

            {/* Document Type Radios */}
            <div className="space-y-2 text-xs font-mono">
              {['All', 'Announcements', 'Concalls', 'Presentations', 'Key points'].map((type) => (
                <button
                  key={type}
                  onClick={() => setSelectedDocType(type)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl border text-left transition-all ${
                    selectedDocType === type
                      ? 'bg-blue-600/20 border-blue-500/40 text-blue-300 font-bold'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{type}</span>
                  {selectedDocType === type && <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />}
                </button>
              ))}
            </div>

            {/* Results Containing */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                Results Containing:
              </span>
              {(['All words', 'Exact phrase', 'Any of the word'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMatchType(m)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-mono transition-colors ${
                    matchType === m ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{m}</span>
                  {matchType === m && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                </button>
              ))}
            </div>

            {/* Quick Reliance Links */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs font-mono">
              <span className="text-slate-400 text-[10px] uppercase font-bold block">
                Quick Screener Shortcuts:
              </span>
              <button
                onClick={() => setSearchTerm('reliance')}
                className="block text-blue-400 hover:underline text-left"
              >
                › Reliance Industries Concalls
              </button>
              <button
                onClick={() => setSearchTerm('Jio')}
                className="block text-cyan-400 hover:underline text-left"
              >
                › Reliance Jio 5G &amp; ARPU Updates
              </button>
              <button
                onClick={() => setSearchTerm('Trends')}
                className="block text-emerald-400 hover:underline text-left"
              >
                › Reliance Trends Retail Comparisons
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
