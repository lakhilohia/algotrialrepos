import React, { useState } from 'react';
import {
  TrendingUp,
  ShieldCheck,
  Target,
  Sparkles,
  Clock,
  AlertTriangle,
  PlayCircle,
  HelpCircle,
  CheckCircle,
  Zap,
  ChevronRight,
  Calculator,
} from 'lucide-react';
import { StockItem, AIAuditResult } from '../types/trading';
import { CandlestickChart } from './CandlestickChart';
import { PositionSizerModal } from './PositionSizerModal';

interface TradingTerminalProps {
  stocks: StockItem[];
  selectedStock: StockItem;
  setSelectedStock: (stock: StockItem) => void;
  onExecuteTrade: (stock: StockItem, quantity: number) => void;
}

export const TradingTerminal: React.FC<TradingTerminalProps> = ({
  stocks,
  selectedStock,
  setSelectedStock,
  onExecuteTrade,
}) => {
  const [timeframe, setTimeframe] = useState<string>('15m');
  const [isSizerOpen, setIsSizerOpen] = useState(false);
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResult, setAuditResult] = useState<AIAuditResult | null>(null);
  const [auditError, setAuditError] = useState<string | null>(null);

  const currencySymbol = selectedStock.exchange === 'NASDAQ' ? '$' : '₹';
  const setup = selectedStock.algoSetup;

  const handleRunAiAudit = async () => {
    setIsAuditing(true);
    setAuditError(null);
    try {
      const res = await fetch('/api/ai/audit-stock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol: selectedStock.symbol,
          currentPrice: selectedStock.price,
          change24h: selectedStock.changePercent,
          rsi: selectedStock.rsi,
          trend: selectedStock.trend,
          timeframe,
          sector: setup.sector,
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setAuditResult(data.data);
      } else {
        setAuditError(data.error || 'Unable to audit stock');
      }
    } catch (err: any) {
      setAuditError('Server offline or network error while auditing.');
    } finally {
      setIsAuditing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Quick Stock Selector Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-500 font-mono text-[11px] uppercase tracking-wider shrink-0 mr-1">
          Active Watchlist:
        </span>
        {stocks.map((stock) => {
          const isSelected = stock.symbol === selectedStock.symbol;
          const curr = stock.exchange === 'NASDAQ' ? '$' : '₹';
          return (
            <button
              key={stock.symbol}
              onClick={() => {
                setSelectedStock(stock);
                setAuditResult(null);
              }}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border font-mono whitespace-nowrap transition-all shrink-0 ${
                isSelected
                  ? 'bg-slate-800 text-white border-emerald-500 shadow-md shadow-emerald-500/10'
                  : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <span className="font-bold">{stock.symbol}</span>
              <span className="text-slate-500">·</span>
              <span className={stock.change >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {curr}{stock.price.toFixed(1)}
              </span>
              <span
                className={`text-[9px] px-1 py-0.5 rounded font-bold uppercase ${
                  stock.signal === 'STRONG_BUY'
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : stock.signal === 'BUY'
                    ? 'bg-cyan-500/20 text-cyan-300'
                    : stock.signal === 'WAIT_PULLBACK'
                    ? 'bg-amber-500/20 text-amber-300'
                    : 'bg-rose-500/20 text-rose-300'
                }`}
              >
                {stock.signal.replace('_', ' ')}
              </span>
            </button>
          );
        })}
      </div>

      {/* Main Stock Banner & Execution Stats */}
      <div className="p-4 lg:p-5 rounded-xl bg-[#0C101A] border border-slate-800 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700/80 flex items-center justify-center font-extrabold text-white text-base font-mono">
            {selectedStock.symbol.slice(0, 3)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-white tracking-tight">{selectedStock.name}</h2>
              <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-slate-800 text-slate-300 rounded border border-slate-700">
                {selectedStock.exchange}
              </span>
              <span className="text-xs text-slate-400">· {setup.sector}</span>
            </div>
            <div className="flex items-center gap-3 text-xs font-mono text-slate-400 mt-1">
              <span>Day Range: <strong className="text-slate-200">{currencySymbol}{selectedStock.dayLow}</strong> - <strong className="text-slate-200">{currencySymbol}{selectedStock.dayHigh}</strong></span>
              <span>·</span>
              <span>RSI(14): <strong className={selectedStock.rsi > 70 ? 'text-rose-400' : selectedStock.rsi < 30 ? 'text-amber-400' : 'text-emerald-400'}>{selectedStock.rsi}</strong></span>
              <span>·</span>
              <span>Vol: <strong className="text-slate-200">{(selectedStock.volume / 1000000).toFixed(2)}M</strong></span>
              {selectedStock.symbol === 'RELIANCE' && (
                <>
                  <span>·</span>
                  <span className="text-blue-400 font-bold bg-blue-500/10 px-1.5 py-0.5 rounded border border-blue-500/20">
                    Screener: P/E 24.8 · ROCE 10.6% (Post-Bonus ₹1,300 Base)
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Live Institutional Indicators Strip */}
        <div className="flex flex-wrap items-center gap-6 font-mono text-xs">
          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider">Current Market Price</div>
            <div className="text-xl font-extrabold text-white">
              {currencySymbol}{selectedStock.price.toFixed(2)}
              <span className={`ml-2 text-xs font-semibold ${selectedStock.change >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {selectedStock.change >= 0 ? '+' : ''}{selectedStock.change.toFixed(2)} ({selectedStock.changePercent}%)
              </span>
            </div>
          </div>

          <div className="h-8 w-px bg-slate-800 hidden sm:block" />

          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider">Algo Win Probability</div>
            <div className="text-lg font-bold text-emerald-400 flex items-center gap-1.5">
              <span>{setup.winProbability}%</span>
              <span className="text-[10px] font-normal text-slate-400">(412 Backtests)</span>
            </div>
          </div>

          <div className="h-8 w-px bg-slate-800 hidden sm:block" />

          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider">Risk / Reward (R:R)</div>
            <div className="text-lg font-bold text-cyan-300">{setup.riskRewardRatio}</div>
          </div>
        </div>
      </div>

      {/* Main Grid: Left = Chart & Order Block, Right = Algo Direct Guidance (Entry, Profit Booking, Stop Loss) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (Chart & Setup Details) */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-5">
          <CandlestickChart
            candles={selectedStock.candles}
            symbol={selectedStock.symbol}
            currencySymbol={currencySymbol}
            currentPrice={selectedStock.price}
            algoSetup={setup}
            timeframe={timeframe}
            setTimeframe={setTimeframe}
          />

          {/* Setup Breakdown & Institutional Edge */}
          <div className="p-5 rounded-xl bg-[#0C101A] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <h3 className="text-sm font-bold text-white tracking-tight uppercase font-mono">
                  {setup.name}
                </h3>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                Institutional Confidence: {setup.winProbability}%
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{setup.description}</p>
            <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800/80 text-xs font-mono text-slate-300">
              <strong className="text-cyan-400">Trigger Formula: </strong>
              {setup.triggerCondition}
            </div>
          </div>
        </div>

        {/* Right Column: THE CORE GUIDANCE PANEL */}
        {/* "When to invest in which stock at which time, when to exit with booking profit, and kab stop loss lagana hai" */}
        <div className="lg:col-span-5 xl:col-span-4 space-y-4">
          <div className="p-5 rounded-xl bg-[#0E1320] border border-slate-700/80 shadow-2xl space-y-5">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest font-bold">
                  StrykeX Algo Directive
                </span>
                <h3 className="text-base font-extrabold text-white">Execution Playbook</h3>
              </div>
              <span className="px-2 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-mono text-xs font-bold uppercase">
                {selectedStock.signal.replace('_', ' ')}
              </span>
            </div>

            {/* Step 1: WHEN TO INVEST (KAB KHARIDNA HAI) */}
            <div className="p-3.5 rounded-lg bg-slate-900/90 border border-cyan-500/30 space-y-2">
              <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs uppercase tracking-wide">
                <Clock className="w-4 h-4 text-cyan-400 shrink-0" />
                1. When to Invest (Kab Kharidna Hai)
              </div>
              <div className="font-mono text-xs text-slate-200">
                Ideal Entry: <strong className="text-cyan-400 text-sm">{currencySymbol}{setup.entryZone.ideal.toFixed(2)}</strong>
                <span className="text-slate-400 text-[11px] ml-2">
                  (Zone: {currencySymbol}{setup.entryZone.min} - {currencySymbol}{setup.entryZone.max})
                </span>
              </div>
              <div className="text-[11px] text-slate-300 leading-snug">
                <strong className="text-white">Timing: </strong>{setup.triggerTime}
              </div>
            </div>

            {/* Step 2: KAB STOP LOSS LAGANA HAI */}
            <div className="p-3.5 rounded-lg bg-rose-950/20 border border-rose-500/40 space-y-2">
              <div className="flex items-center gap-2 text-rose-300 font-bold text-xs uppercase tracking-wide">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                2. Kab Stop Loss Lagana Hai (SL Rules)
              </div>
              <div className="font-mono text-xs text-slate-200 flex items-center justify-between">
                <span>Hard Stop Loss Price:</span>
                <strong className="text-rose-400 text-sm font-bold">
                  {currencySymbol}{setup.stopLoss.price.toFixed(2)} (-{setup.stopLoss.riskPercent}%)
                </strong>
              </div>
              <div className="p-2.5 rounded bg-rose-950/40 border border-rose-800/40 text-[11px] text-rose-200/90 leading-snug">
                <strong>{setup.stopLoss.timingRule}</strong>
              </div>
              <div className="text-[11px] text-slate-300 leading-snug">
                <strong className="text-amber-300">Trailing Rule: </strong>
                {setup.stopLoss.trailingRule}
              </div>
            </div>

            {/* Step 3: WHEN TO EXIT WITH BOOKING PROFIT (PROFIT BOOKING) */}
            <div className="p-3.5 rounded-lg bg-emerald-950/20 border border-emerald-500/30 space-y-2.5">
              <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs uppercase tracking-wide">
                <Target className="w-4 h-4 text-emerald-400 shrink-0" />
                3. When to Exit with Profit (Profit Booking)
              </div>

              {/* Target 1 */}
              <div className="p-2 rounded bg-slate-900/90 border border-emerald-500/20 text-xs font-mono space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-emerald-400 font-bold">Target 1 (Book 50% Qty):</span>
                  <span className="text-white font-bold">{currencySymbol}{setup.target1.price.toFixed(2)} (+{setup.target1.gainPercent}%)</span>
                </div>
                <div className="text-[11px] text-slate-400">{setup.target1.instruction}</div>
              </div>

              {/* Target 2 */}
              <div className="p-2 rounded bg-slate-900/90 border border-emerald-500/20 text-xs font-mono space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-emerald-300 font-bold">Target 2 (Book 30% Qty):</span>
                  <span className="text-white font-bold">{currencySymbol}{setup.target2.price.toFixed(2)} (+{setup.target2.gainPercent}%)</span>
                </div>
                <div className="text-[11px] text-slate-400">{setup.target2.instruction}</div>
              </div>

              {/* Runner Target 3 */}
              <div className="p-2 rounded bg-slate-900/90 border border-slate-800 text-xs font-mono space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-cyan-300 font-bold">Target 3 Runner (20% Qty):</span>
                  <span className="text-white font-bold">{currencySymbol}{setup.target3Runner.price.toFixed(2)} (+{setup.target3Runner.gainPercent}%)</span>
                </div>
                <div className="text-[11px] text-slate-400">{setup.target3Runner.instruction}</div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => setIsSizerOpen(true)}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs uppercase tracking-wider font-mono shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
              >
                <Calculator className="w-4 h-4" />
                Calculate Position Size &amp; Execute
              </button>

              <button
                onClick={handleRunAiAudit}
                disabled={isAuditing}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-xs font-mono transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-purple-400" />
                {isAuditing ? 'Generating Institutional Audit...' : 'Ask Gemini: Deep Algo Audit'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* AI Live Audit Results Modal / Section */}
      {auditResult && (
        <div className="p-6 rounded-xl bg-[#0D121F] border border-purple-500/40 shadow-2xl space-y-4 animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white tracking-tight">
                  Gemini Algorithmic Audit: {selectedStock.symbol}
                </h3>
                <p className="text-xs text-slate-400">
                  Real-time algorithmic check with institutional smart money verification
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 font-mono text-xs">
              <span className="text-slate-400">Verdict:</span>
              <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300 font-bold uppercase border border-emerald-500/30">
                {auditResult.verdict} ({auditResult.confidenceScore}%)
              </span>
            </div>
          </div>

          {/* Hinglish Direct Guidance Box */}
          <div className="p-4 rounded-lg bg-gradient-to-r from-emerald-950/30 to-cyan-950/30 border border-emerald-500/30 text-xs text-slate-200 leading-relaxed font-sans">
            <span className="font-bold text-emerald-400 font-mono uppercase text-[11px] block mb-1">
              Direct Trader Guidance (Hinglish/English):
            </span>
            {auditResult.hinglishSummary}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-slate-400 text-[11px]">When To Invest (Entry):</span>
              <div className="text-emerald-400 font-bold">{auditResult.entryPriceZone}</div>
              <div className="text-[11px] text-slate-300 font-sans">{auditResult.entryTiming}</div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-slate-400 text-[11px]">When To Exit (Targets):</span>
              <div className="text-cyan-300 font-bold">
                T1: ₹{auditResult.target1.price} (+{auditResult.target1.percentGain}%) | T2: ₹{auditResult.target2.price}
              </div>
              <div className="text-[11px] text-slate-300 font-sans">{auditResult.target1.action}</div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-rose-400 text-[11px] font-bold">Kab Stop Loss Lagana Hai:</span>
              <div className="text-rose-300 font-bold">
                SL: ₹{auditResult.stopLoss.price} ({auditResult.stopLoss.percentRisk}%)
              </div>
              <div className="text-[11px] text-slate-300 font-sans">{auditResult.stopLoss.kabLaganaHai}</div>
            </div>
          </div>

          <div className="text-xs text-slate-400 border-t border-slate-800/80 pt-2 flex items-center justify-between">
            <span>Risk-Reward: <strong className="text-white">{auditResult.riskRewardRatio}</strong></span>
            <span>Reasoning: <span className="text-slate-300 font-sans">{auditResult.institutionalReasoning}</span></span>
          </div>
        </div>
      )}

      {/* Position Sizer Modal */}
      <PositionSizerModal
        stock={selectedStock}
        isOpen={isSizerOpen}
        onClose={() => setIsSizerOpen(false)}
        onExecuteTrade={(qty) => onExecuteTrade(selectedStock, qty)}
      />
    </div>
  );
};
